------------------------------------------------------------
-- file		avgexplore.sql "event name" sample_time(sec)
-- desc		Explore wait time average (<"event name"> <sample seconds>)
-- author	Craig A. Shallahamer, craig@orapub.com
-- orig		09-Nov-2010
-- lst upt	09-Nov-2010 
-- copyright	(c)2010 OraPub, Inc.
-- example	@avgexplore "db file async I/O submit" 60
------------------------------------------------------------

prompt 
prompt 
prompt Exploring averages for wait event, &1, with a sample duration of &2 seconds

set termout off

def ev_name='&1'
def sleep_time=&2

set tab off
alter session set commit_write="batch,nowait";
drop table op_histogram_snap;
create table op_histogram_snap as select * from v$event_histogram where 1=0;

col val1 new_val totw noprint 
col val2 new_val timw noprint 
select	total_waits val1,time_waited val2
from	v$system_event
where	event = '&ev_name'
/
truncate table op_histogram_snap
/
insert into op_histogram_snap 
  select * from v$event_histogram
  where  event='&ev_name'
/
-- If the commit below does not occur, somehow 22 rows get inserted.
commit;
exec dbms_lock.sleep(&sleep_time)
/
set termout on
set verify off echo off feedback off

set heading on
select	cur.wait_time_milli max_bucket_time_ms,
	cur.wait_count-prev.wait_count occurs
from	v$event_histogram cur,
	op_histogram_snap prev
where	cur.event# 			= prev.event#
  and	cur.event 			= prev.event
  and	cur.wait_time_milli = prev.wait_time_milli
  and   cur.event  			= '&ev_name'
/

set heading off
select 'standard average wait time = '||round(10*((time_waited-&timw)/(total_waits-&totw+0.0000000010)),3)||' ms, ( total ms waited = '|| 
       round(10*(time_waited-&timw),3) ||', total waits = ' || round((total_waits-&totw+0.0000000010),0) || ' )'
from	v$system_event
where	event = '&ev_name'
/

set serveroutput on buffer 2560000
SET SERVEROUTPUT ON SIZE 1000000
begin
declare
  cursor main_cur is 
	select	cur.wait_time_milli dur_ms,
		cur.wait_count-prev.wait_count occurs
	from	v$event_histogram cur,
		op_histogram_snap prev
	where	cur.event# 		= prev.event#
  	  and	cur.event 		= prev.event
 	  and	cur.wait_time_milli 	= prev.wait_time_milli
	  and   cur.event  		= '&ev_name';
  main_rec main_cur%ROWTYPE;
  tot_occurs  number;
  sum_product number;
  wa          number;
  prev_bucket number;
  between_bucket number;
begin
  tot_occurs := 0;
  sum_product:= 0;
  for main_rec in main_cur
  loop
    tot_occurs		:= tot_occurs + main_rec.occurs;
    prev_bucket		:= floor(main_rec.dur_ms / 2);
    between_bucket	:= prev_bucket + ((main_rec.dur_ms - prev_bucket)/2) ;
    sum_product		:= sum_product + (main_rec.occurs * between_bucket);
  end loop;
  wa := round(sum_product / (tot_occurs+0.000000000010),3) ;
  dbms_output.put_line('weighted average wait time = '||wa||' ms, ( sum product = '||round(sum_product,3)|| ', total waits = '||round(tot_occurs,0) || ' )');
end;
end;
/

set heading on
set termout on
start osmclear

