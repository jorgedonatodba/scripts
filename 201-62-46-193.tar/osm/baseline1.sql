------------------------------------------------------------
-- file		baseline1.sql
-- desc		Get and display performance baseline statistics
-- author	Craig A. Shallahamer, craig@orapub.com
-- orig		18-July-2015
-- lst upt	18-July-2015 
-- copyright (c)2015 OraPub, Inc.
--
-- @osmsetvar must be run to init variables


set tab off
set echo off
set feedback off
set heading on
set verify off
set termout on
set serveroutput on
 
prompt osmsetvar must be run once to init variables
prompt

@sysstatbl
@oscpuutil

