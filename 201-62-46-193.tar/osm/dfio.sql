-- ********************************************************************
-- * Copyright Notice   : (c)1998,2000,2002,2005 OraPub, Inc.
-- * Filename		: dfio.sql 
-- * Author		: Craig A. Shallahamer
-- * Original		: 17-AUG-98
-- * Last Update	: 14-feb-05
-- * Description	: Database file (dbf and redo) i/o basic data.
-- *			  Used to help spot heavy hit files.
-- * Usage		: start dflio.sql
-- ********************************************************************

def osm_prog	= 'dfio.sql'
def osm_title	= 'Oracle DB File I/O Information'

col dbf	    heading 'Data File'	 	format  A40 justify c trunc
col writes  heading 'Write|Req(k)'	format  9,999,999
col reads   heading 'Read|Req(k)'     	format  99,999,999
col bwrites heading 'Blk|Writes(k)'	format  9,999,999
col breads  heading 'Blk|Reads(k)'     	format  99,999,999
col mbw     heading 'Bytes|Writes(M)'	format  9,999,999
col mbr     heading 'Bytes|Reads(M)'   	format  99,999,999
col pctfts  heading 'MBR%'       	format        90.0

set termout off
col val1 new_val mbrc noprint
select value val1
from v$parameter
where name = 'db_file_multiblock_read_count'
/
col val1 new_val bs noprint
select value val1
from v$parameter
where name = 'db_block_size'
/

start osmtitlem

select
	name		            dbf,
	phywrts/1000	            writes,
        phyblkwrt                   bwrites,
        phyblkwrt*&bs/1024/1024     mbw,
	phyrds/1000                 reads,
        phyblkrd/1000               breads,
        phyblkrd*&bs/1024/1024      mbr,
	100*(phyblkrd/(phyrds+0.01))/&mbrc  pctfts
from	v$datafile a,
	v$filestat b
where   a.file# = b.file#
union
select
	name		            dbf,
	phywrts/1000	            writes,
        phyblkwrt                   bwrites,
        phyblkwrt*&bs/1024/1024     mbw,
	phyrds/1000                 reads,
        phyblkrd/1000               breads,
        phyblkrd*&bs/1024/1024      mbr,
	100*(phyblkrd/(phyrds+0.01))/&mbrc  pctfts
from	v$tempfile a,
	v$tempstat b
where   a.file# = b.file#
union
select
	'Redo Log Files'	dbf,
	writes.value/1000	writes,
	-1			bwrites,
	bytes_written.value/1024/1024 mbw,
	-1			reads,
	-1			breads,
	-1			mbr,
	-1			pcfts
from	v$sysstat bytes_written,
	v$sysstat writes
where	bytes_written.name = 'redo size'
  and	writes.name = 'redo writes'
order by 4 desc,
         1 desc
/

start osmclear
