-- ********************************************************************
-- * Copyright Notice  : (c)2015 OraPub, Inc.
-- * Filename          : getgcrec.sql - Get RAC CR buffer received 
-- *                     times and generate R code for visual hist analysis
-- * Author            : Craig Shallahamer, craig@orapub.com
-- * Original          : 8-Oct-2015
-- * Last Update       : 8-Oct-2015
-- * Description       : Get RAC interconnect times using GC cr block received times.
-- *                     The output is formatted for easily analysis in R.
-- * Usage             : @getgcrec
-- *                     @getgcrec 30 2 1
-- ********************************************************************

-- All output is formatted so you can copy/paste directly into 
-- R ( r-project.org )

-- This script does ZERO DDL and ZERO DML and does not use DBMS_Lock.sleep
-- This means you can simply copy and paste the code into SQL*Plus.

-- You want lots of samples... at least 30 but 100 is better, 500 even better.

-- You have three execution strategies:
--
-- 1. Standard with parameters given on command line
--    @getgcrec  sample_duration_s sample_time_s rac_node_number

--    @getgcrec 10 1    1    -- test
--	  @getgcrec 10 0.10 1
--    @getgcrec 180 2 1

-- 2. Copy and paste
--    Copy everything between the obvious COPY/PASTE comments below
--    Paste into sqlplus

-- 3. Have sqlplus prompt you for the input defines
--    @getgcrec 


set tab off
set verify off
set linesize 300
set trimspool on
set serveroutput on

undef sampleTimeSec
undef sampleDeltaSec
undef instNo

prompt Parameter 1 is the sampling Time duration in seconds (e.g., 10)
def EnterSampleTimeSec=&1
prompt Parameter 2 is the time for each sample period in seconds (e.g., 1)
def EnterSampleDeltaSec=&2
prompt Parameter 3 is the Oracle instance number (e.g., 3)
def EnterInstNo=&3

-- To Copy/Paste, ensure the below three defines are set

def sampleTimeSec=&EnterSampleTimeSec
def sampleDeltaSec=&EnterSampleDeltaSec
def InstNo=&EnterInstNo

------------------------------------------------------
-- COPY/PASTE START HERE (make sure the two defines above are set)

set tab off
set verify off
set linesize 300
set trimspool on
set serveroutput on
def MaxSampleLoops=9000 -- for safety

def maxSampleLoops
def sampleTimeSec
def sampleDeltaSec
def instNo

prompt
prompt Collecting node &instNo RAC GC Received times (ms) for &sampleTimeSec seconds with &sampleDeltaSec second samples...
prompt

DECLARE
	looper_var					number;
	time_start_var				timestamp;	
	sample_no_var				number;
	zero_samples_var			number;
	startBlocksReceived_var		number;
	startBlockReceiveTime_var	number;
	endBlocksReceived_var		number;
	endBlockReceiveTime_var		number;
	timer_timestamp_var			timestamp;
	avgBlkRecTimeMs				number;
	
BEGIN
	
	sample_no_var		:= 0;
	zero_samples_var	:= 0 ;
	time_start_var 		:= current_timestamp ;

	-- get the startup values
	--
	select	b2.value,b1.value
	into	startBlocksReceived_var, startBlockReceiveTime_var
	from	gv$sysstat b1, gv$sysstat b2
	where	b1.name='gc cr block receive time'
	  and	b2.name='gc cr blocks received'
	  and	b1.inst_id = &instNo
	  and	b1.inst_id=b2.inst_id
	;
	
	for looper_var in 1..&maxSampleLoops
	loop
	

		-- This is a horrible thing to do, but it is
		-- an alternative when dbms_lock is not available
		-- Better is:
		-- dbms_lock.sleep(&sampleDeltaSec);
		--
		timer_timestamp_var := current_timestamp;
		while ( current_timestamp < ( timer_timestamp_var + interval '&sampleDeltaSec' second )) 
		loop
			null;
		end loop;
	
		-- get the end values and do the match for this loop
		--
		select	b2.value,b1.value
		into	endBlocksReceived_var, endBlockReceiveTime_var
		from	gv$sysstat b1, gv$sysstat b2
		where	b1.name='gc cr block receive time'
		  and	b2.name='gc cr blocks received'
		  and	b1.inst_id = &instNo
		  and	b1.inst_id=b2.inst_id
		;	
	
		begin
			avgBlkRecTimeMs := 10 *
				(endBlockReceiveTime_var-startBlockReceiveTime_var)/(endBlocksReceived_var-startBlocksReceived_var) ;
		exception
			when others then
				null;
		end;
		
		if (endBlockReceiveTime_var-startBlockReceiveTime_var) = 0 then
			zero_samples_var := zero_samples_var + 1 ;
		else
			sample_no_var := sample_no_var + 1;
			dbms_output.put_line( round(avgBlkRecTimeMs,5)||' , ' );
		end if;
			
		startBlocksReceived_var		:= endBlocksReceived_var ;
		startBlockReceiveTime_var	:= endBlockReceiveTime_var ;
		
		if ( current_timestamp > ( time_start_var + interval '&sampleTimeSec' second )) then
			exit;
		end if;
	end loop;
	
	dbms_output.put_line('------------');
	dbms_output.put_line( 'There were '|| sample_no_var ||' VALID samples collected.');
	dbms_output.put_line( 'There were '|| zero_samples_var ||' zero-time samples collected.');
	dbms_output.put_line('Zero-time samples are skew your data, because they are likely not really zero.');
	dbms_output.put_line('Reduce zero-time samples by increasing the sample period, not sample time.');
	
END;
/

	
prompt Done collecting interconnect times (in milliseconds)
prompt
prompt Here is what to copy and paste into R
prompt
prompt ds<-c(
prompt [ the above timing data and remove the last comma ]
prompt )
prompt summary(ds)
prompt hist(ds)
prompt hist(ds,breaks=10)
prompt hist(ds,breaks=20)
prompt
prompt Enjoy!


