-- ********************************************************************
-- * Copyright Notice   : (c)1998 OraPub, Inc.
-- * Filename		: ip - Version 1.0
-- * Author		: Craig A. Shallahamer
-- * Original		: 17-AUG-98
-- * Last Update	: 20-Nov-2014
-- * Description	: Instance parameter report
-- * Usage		: start ip.sql
-- ********************************************************************

def p_name=&1

def osm_prog	= 'ip.sql'
def osm_title	= 'Instance Parameters'
start osmtitle

col namex  format a35 heading 'Instance Parameter' wrap
col valuex format a15 heading 'Value'              wrap
col isdefaultx format a8 heading 'Default|Value?'  
col ismodifiedx format a13 heading 'Changed After|Startup?' 

select
  name namex,
  value valuex,
  isdefault isdefaultx,
  ismodified ismodifiedx
from
  v$parameter
where name like '&p_name%'
order by
  name,
  value
/

start osmclear

