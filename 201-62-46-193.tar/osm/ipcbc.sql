-- ********************************************************************
-- * Copyright Notice   : (c)2009 OraPub, Inc.
-- * Filename           : ipcbc
-- * Author             : Craig A. Shallahamer
-- * Original           : 03-mar-09
-- * Last Update        : 03-mar-09
-- * Description        : Instance parameter related to the cache
-- *			  buffer chains.
-- * Usage              : Must be run as Oracle user "sys".
-- *			  start ipcbc.sql
-- * Note               : Based upon the ipx.sql report.
-- ********************************************************************


def osm_prog    = 'ipcbc.sql'
def osm_title   = 'Display CBC Related Instance Parameters'
start osmtitle

col param 	format a50 heading "Instance Param and Value" word_wrapped
col description format a20 heading "Description" word_wrapped
col dflt 	format a5  heading "Dflt?" word_wrapped

select  rpad(i.ksppinm, 35) || ' = ' || v.ksppstvl param,
        i.ksppdesc description,
        v.ksppstdf dflt
from    x$ksppi	     i,
        x$ksppcv	     v
where   v.indx = i.indx
  and     v.inst_id = i.inst_id
  and     i.ksppinm in
          ('db_block_buffers','_db_block_buffers','db_block_size',
           '_db_block_hash_buckets','_db_block_hash_latches'
          )
order by i.ksppinm
/

start osmclear

