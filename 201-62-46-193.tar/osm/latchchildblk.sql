-- ********************************************************************
-- * Copyright Notice   : (c)2011,2015 OraPub, Inc.
-- * Filename		: latchchildblk.sql 
-- * Author		: Craig A. Shallahamer
-- * Original		: 29-Nov-2015
-- * Last Update	: 29-Nov-2015
-- * Description	: Show which block for given child latch addresses.
-- *                      latch over a given period of time.
-- * Usage		: start latchchild.sql :latch# :sleep_seconds
-- ********************************************************************

def cycles_in=&1
def sleep_in=&2
def childaddrs_in="&3"

def osm_prog	= 'latchchildblk.sql'
def osm_title	= 'Hot Buffer For Child Latch Activity Report (ADDRS:&childaddrs_in)'

start osmtitle
set linesize 110

col delta_gets 	  heading "Gets"	  form     999,999,99,9990
col delta_sleeps  heading "Sleeps"	  form     999,999,99,9990
col addr 	  heading "Latch|Address" form     a20

drop table op_interim;
create table op_interim (hladdr raw(8), file# number, 
  block# number, tch number);

prompt "Gathering sample data now..."

declare
  i number;
begin
  for i in 1..&cycles_in
  loop
    insert into op_interim 
      select hladdr,file#, dbablk, tch
      from   x$bh
      where  hladdr in (&childaddrs_in);
    dbms_lock.sleep(&sleep_in);
  end loop;
end;
/

select hladdr, file#, block#,
       count(*), min(tch) min, median(tch) med,
       round(avg(tch)) avg, max(tch) max
from   op_interim
group by hladdr, file#, block#
order by 3
/

start osmclear
