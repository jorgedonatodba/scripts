-- ********************************************************************
-- * Copyright Notice   : (c)2010 OraPub, Inc.
-- * Filename			: latchclass.sql 
-- * Author				: Craig A. Shallahamer
-- * Original			: 21-Jan-2010
-- * Last Update		: 21-Jan-2010
-- * Description		: Latch class details
-- * Usage				: start latchclass.sql as Oracle user sys
-- ********************************************************************

def osm_prog	= 'latchclass.sql'
def osm_title	= 'Latch Contention Report'

start osmtitle
set linesize 80

col latch_name format a40


select	kslltnam latch_name,
		class_ksllt latch_class,
		c.spin class_spin_count
from	x$kslltr r,
		x$ksllclass c
where	c.indx = r.class_ksllt
  and	r.class_ksllt > 0
 
/


start osmclear
