-- ********************************************************************
-- * Copyright Notice   : (c)2004 OraPub, Inc.
-- * Filename		: latchx.sql 
-- * Author		: Craig A. Shallahamer
-- * Original		: 17-may-04
-- * Last Update	: 17-may-04
-- * Description	: Delta Latch contention information for tuning
-- * Usage		: start latchx.sql
-- ********************************************************************


set echo off
set feedback off
set heading off
set verify off

set echo off
set feedback off
set heading on
set verify off

def osm_prog	= 'latchx.sql'
def osm_title	= 'Delta Latch Contention Report'

start osmtitle
set linesize 95

col lname 	heading "Latch Name"	form A24 trunc
col wtime	heading "Wait Time|(sec)" form 99,999,990
col pct_impact	heading "%Impt"	form       90.0
col impact	heading "Impact"	form    9990.00
col gts 	heading "Gets(k)"	form     999990
col mss 	heading "Misses"	form     999990
col hit_ratio	heading "Hit Ratio"	form      0.000
col slps 	heading "Sleeps|(k)"	form     9990
col mss 	heading "Misses"	form     999990
col slpsgets 	heading "Sleeps/|Gets"  form     90.000

select	b.name lname,
	(((b.sleeps-a.sleeps)*((b.sleeps-a.sleeps)/decode((b.gets-a.gets),0,1,(b.gets-a.gets))))/(sum((b.sleeps-a.sleeps)*((b.sleeps-a.sleeps)/decode((b.gets-a.gets),0,1,(b.gets-a.gets)))) over ()))*100 pct_impact,
	(b.sleeps-a.sleeps)*((b.sleeps-a.sleeps)/decode((b.gets-a.gets),0,1,(b.gets-a.gets))) impact,
	(b.gets-a.gets)/1000 gts,
	(b.misses-a.misses) mss,
	round(((b.gets-a.gets)-(b.misses-a.misses))/decode((b.gets-a.gets),0,1,(b.gets-a.gets)),3) hit_ratio,
	(b.sleeps-a.sleeps)/1000 slps,
	round((b.sleeps-a.sleeps)/decode((b.gets-a.gets),0,1,(b.gets-a.gets)),3) slpsgets
from	v$latch b,
	o$latch_snap a
where   a.name = b.name
  and   (b.sleeps-a.sleeps)*((b.sleeps-a.sleeps)/decode((b.gets-a.gets),0,1,(b.gets-a.gets))) > 0.0
order by impact desc
/

drop table o$latch_snap;
create table o$latch_snap as select * from v$latch;

start osmclear

