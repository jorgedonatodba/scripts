------------------------------------------------------------
-- file		listeventcodes.sql
-- desc		list all the Oracle event codes
-- author	Craig A. Shallahamer, craig@orapub.com
-- orig		05-Dec-2014
-- lst upt	04-Dec-2014 
-- copyright (c)2014 OraPub, Inc.
-- example: @listeventcodes.sql " "
-- example: @listeventcodes.sql dump
-- example: @listeventcodes.sql trace
--

set verify off

def filter="&1"

select version from v$instance;

set serveroutput on
declare
  text_v varchar2(1000);
begin
    dbms_output.enable(1000000) ;
    for oerrn in 10000..10999 loop
    begin
       if sqlerrm (-oerrn) not like '%Message % not found%' then
            text_v := sqlerrm (-oerrn);
            If instr(upper(text_v),upper('&filter')) > 0 then
                 dbms_output.put_line (sqlerrm (-oerrn));
            end if;
       end if;
    exception when others then
        null;
   end;
   end loop;
end;
/

start osmclear
