
col object_name format a20
col mode_held format a10
col mode_requested format a10
col lock_type format a12 heading 'Lock Type'
col holding_session format 999999 heading 'holder'
col waiting_session format 999999 heading 'waiter'
select	holding_session,
  	waiting_session,
	lock_type,
	mode_held,
	mode_requested,
	lock_id1,
	lock_id2
from	sys.dba_waiters w
/

