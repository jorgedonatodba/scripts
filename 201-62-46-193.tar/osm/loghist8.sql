column "00" format A2 
column "01" format A2
column "02" format A2
column "03" format A2
column "04" format A2
column "05" format A2
column "06" format A2
column "07" format A2
column "08" format A2
column "09" format A2
column "10" format A2
column "11" format A2
column "12" format A2
column "13" format A2
column "14" format A2
column "15" format A2
column "16" format A2
column "17" format A2
column "18" format A2
column "19" format A2
column "20" format A2
column "21" format A2
column "22" format A2
column "23" format A2

set heading off
set lines 60
set feedback off

select 
'     Redologfile : '||round(max(d.bytes)/1024,0)||' K'
from v$log      d
/

set heading on
set lines 120

select substr(time,1,5) day,
to_char(sum(decode(substr(time,10,2),'00',1,0))) "00",
to_char(sum(decode(substr(time,10,2),'01',1,0))) "01",
to_char(sum(decode(substr(time,10,2),'02',1,0))) "02",
to_char(sum(decode(substr(time,10,2),'03',1,0))) "03",
to_char(sum(decode(substr(time,10,2),'04',1,0))) "04",
to_char(sum(decode(substr(time,10,2),'05',1,0))) "05",
to_char(sum(decode(substr(time,10,2),'06',1,0))) "06",
to_char(sum(decode(substr(time,10,2),'07',1,0))) "07",
to_char(sum(decode(substr(time,10,2),'08',1,0))) "08",
to_char(sum(decode(substr(time,10,2),'09',1,0))) "09",
to_char(sum(decode(substr(time,10,2),'10',1,0))) "10",
to_char(sum(decode(substr(time,10,2),'11',1,0))) "11",
to_char(sum(decode(substr(time,10,2),'12',1,0))) "12",
to_char(sum(decode(substr(time,10,2),'13',1,0))) "13",
to_char(sum(decode(substr(time,10,2),'14',1,0))) "14",
to_char(sum(decode(substr(time,10,2),'15',1,0))) "15",
to_char(sum(decode(substr(time,10,2),'16',1,0))) "16",
to_char(sum(decode(substr(time,10,2),'17',1,0))) "17",
to_char(sum(decode(substr(time,10,2),'18',1,0))) "18",
to_char(sum(decode(substr(time,10,2),'19',1,0))) "19",
to_char(sum(decode(substr(time,10,2),'20',1,0))) "20",
to_char(sum(decode(substr(time,10,2),'21',1,0))) "21",
to_char(sum(decode(substr(time,10,2),'22',1,0))) "22",
to_char(sum(decode(substr(time,10,2),'23',1,0))) "23"
from (select to_char(first_time,'MM/DD/YY HH24:MI:SS') time from v$log_history)
group by substr(time,1,5)
/

set lines 80
set feedback off

