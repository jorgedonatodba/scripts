select * from x$kcbwds
/

