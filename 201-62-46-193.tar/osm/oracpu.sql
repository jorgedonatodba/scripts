------------------------------------------------------------
-- file		oracpu.sql
-- desc		Oracle CPU breakdown (since startup)
-- author	Craig A. Shallahamer, craig@orapub.com
-- orig		04-April-07
-- lst upt	04-April-07 
-- copyright	(c)2007 OraPub, Inc.
------------------------------------------------------------

set echo off
set feedback off
set heading on
set verify off

def osm_prog	= 'oracpu.sql'
def osm_title	= 'Oracle CPU Consumption Breakdown Since Startup'

start osmtitle

col name		format a35	heading "Statistic" trunc
col the_time	format 999999999990.0	heading "Time (min)"

select 	stat_name name,
		(value/1000000)/60 the_time
from	v$sys_time_model
order by 2 desc,1
/

start osmclear

