prompt DB Time = DB CPU time + Total Wait Event time
prompt 
prompt DB CPU time: is the service time as shown at top of rtsysx.
prompt
prompt Total WE time: is all but the background process time shown below
prompt      and is also equal to the total wait time at the top of rtsysx.
prompt      Both IO and non-IO wait time is wrapped up into this time.
prompt
prompt However, due to sampling errors, the numbers below will not match the
prompt the numbers from the rest of rtsysx.  But the conclusion reached should
prompt be the same.
prompt
