------------------------------------------------------------
-- file		oracpux.sql
-- desc		Session wait statitics percentage reporting.
-- author	Craig A. Shallahamer, craig@orapub.com
-- orig		04-April-07
-- lst upt	25-April-07
-- copyright	(c)2007 OraPub, Inc.
------------------------------------------------------------

set echo off
set feedback off
set heading on
set verify off
set termout on

prompt Remember: This report must be run twice so both 
prompt the initial and final values are available.

prompt
start oracputext.sql

def osm_prog	= 'oracpux.sql'
def osm_title	= 'Oracle Service Time (CPU) breakdown (delta)'

start osmtitle

start oracpux2.sql

set echo off
set feedback off
set heading off
set verify off
set termout off

start oracpux1.sql

start osmclear

