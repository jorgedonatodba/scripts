------------------------------------------------------------
-- file		oracpux1.sql
-- desc		Oracle system CPU breakdown DELTA - (gather and store)
-- author	Craig A. Shallahamer, craig@orapub.com
-- orig		04-April-07
-- lst upt	04-April-07 
-- copyright	(c)2007 OraPub, Inc.
------------------------------------------------------------

set echo off
set feedback off
set heading on
set verify off
set termout off

truncate table op_sys_time_model_snap
/
insert /*+ APPEND */ into op_sys_time_model_snap nologging
select * 
from   v$sys_time_model
/
commit;
