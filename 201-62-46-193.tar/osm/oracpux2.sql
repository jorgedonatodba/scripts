------------------------------------------------------------
-- file		oracpux2.sql
-- desc		Oracle system CPU breakdown DELTA - (report)
-- author	Craig A. Shallahamer, craig@orapub.com
-- orig		04-April-07
-- lst upt	04-April-07 
-- copyright	(c)2007 OraPub, Inc.
------------------------------------------------------------

-- Asumption: past data has been gathered via oracpux1.sql

set echo off
set feedback off
set heading on
set verify off
set termout on

col name		format a35	heading "Statistic" trunc
col the_time_m	format 999999999990.00	heading "Delta Time (min)"
col the_time_s	format 999999999990.00	heading "Delta Time (sec)"

select 	t1.stat_name name,
		((t1.value-t0.value)/1000000)/60 the_time_m,
		((t1.value-t0.value)/1000000)    the_time_s		
from	v$sys_time_model t1,
		op_sys_time_model_snap t0
where	t1.stat_name = t0.stat_name
order by 2 desc,1
/

start osmclear

