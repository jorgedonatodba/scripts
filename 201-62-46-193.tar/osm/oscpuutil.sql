------------------------------------------------------------
-- file		oscpuutil.sql
-- desc		OS CPU statitics percentage reporting.
-- author	Craig A. Shallahamer, craig@orapub.com
-- orig		14-July-2015
-- lst upt	12-Aug-2015 
-- copyright	(c)2007,2008,2014 OraPub, Inc.
-- usage	@oscpuutil 
-- note		NO ddl, dml or dbms_lock usage
------------------------------------------------------------ 
-- 
-- Notes:
-- The busy/idle method is being used. See blog.orapub.com for details
-- Average CPU utilization is based on the time between this run and previous
--
set tab off
set echo off
set feedback off
set heading on
set verify off
set termout on

start osmsetvar.sql

set serveroutput on
declare
	util_v		number;
	cores_v		number;
begin
	select (value-:oscpuutil_busy_v)
	into   :oscpuutil_busy_v
	from   v$osstat
	where  stat_name='BUSY_TIME';

	select (value-:oscpuutil_idle_v)
	into   :oscpuutil_idle_v
	from   v$osstat
	where  stat_name='IDLE_TIME';

	--dbms_output.put_line('1 oscpuutil_sssss_v='||:oscpuutil_sssss_v);
	select (to_number(to_char(sysdate,'SSSSS'))-:oscpuutil_sssss_v)
	into   :oscpuutil_sssss_v
	from   dual;
	--dbms_output.put_line('2 oscpuutil_sssss_v='||:oscpuutil_sssss_v);

	util_v	:= :oscpuutil_busy_v / ( :oscpuutil_busy_v + :oscpuutil_idle_v );
	cores_v	:= ( :oscpuutil_busy_v + :oscpuutil_idle_v ) / ( :oscpuutil_sssss_v*100 ) ;
	
	dbms_output.put_line('avg CPU util '||round(util_v,2) ||
    	', that is ' || round(100*util_v,2) ||'% with '||round(cores_v,2)||
		' effective cores over the past '|| :oscpuutil_sssss_v ||' secs.');
    	
    select value
	into   :oscpuutil_busy_v
	from   v$osstat
	where  stat_name='BUSY_TIME';

	select value
	into   :oscpuutil_idle_v
	from   v$osstat
	where  stat_name='IDLE_TIME';
	
	--dbms_output.put_line('3 oscpuutil_sssss_v='||:oscpuutil_sssss_v);
	select to_number(to_char(sysdate,'SSSSS'))
	into   :oscpuutil_sssss_v
	from   dual;
	--dbms_output.put_line('4 oscpuutil_sssss_v='||:oscpuutil_sssss_v);
	
end;
/


prompt
prompt Enter / to run again!


