------------------------------------------------------------
-- file		oscpux1.sql
-- desc		OS CPU breakdown DELTA - (gather and store)
-- author	Craig A. Shallahamer, craig@orapub.com
-- orig		04-April-07
-- lst upt	04-April-07 
-- copyright	(c)2007 OraPub, Inc.
------------------------------------------------------------

set echo off
set feedback off
set heading on
set verify off
set termout off

truncate table op_os_cpu_snap
/
insert /*+ APPEND */ into op_os_cpu_snap nologging
select stat_name,value
from   v$osstat
UNION
select 'the_time',dbms_utility.get_time
from	dual
/
commit;
