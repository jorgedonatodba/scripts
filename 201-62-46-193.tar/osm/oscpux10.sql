------------------------------------------------------------
-- file		oscpux10.sql
-- desc		OS CPU statitics percentage reporting for O10g
-- author	Craig A. Shallahamer, craig@orapub.com
-- orig		04-April-07
-- lst upt	04-April-07 
-- copyright	(c)2007 OraPub, Inc.
------------------------------------------------------------

set echo off
set feedback off
set heading on
set verify off
set termout on

prompt Remember: This report must be run twice so both 
prompt the initial and final values are available.

def osm_prog	= 'oscpux10.sql'
def osm_title	= 'OS CPU breakdown (delta)'

start osmtitle

start oscpux210.sql

set echo off
set feedback off
set heading off
set verify off
set termout off

start oscpux1.sql

start osmclear

