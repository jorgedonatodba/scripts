------------------------------------------------------------
-- file		oscpux2.sql
-- desc		OS CPU breakdown DELTA - (report)
-- author	Craig A. Shallahamer, craig@orapub.com
-- orig		04-April-07
-- lst upt	14-May-07 
-- copyright	(c)2007 OraPub, Inc.
------------------------------------------------------------

-- Asumption: past data has been gathered via oscpux1.sql

set echo off
set feedback off
set heading on
set verify off
set termout on

col name		format a35	heading "Statistic" trunc
col pct			format 9990.00	heading "Percent"

prompt
select 	decode(t1.stat_name,'USER_TICKS','User','NICE_TICKS','Nice','IO_WAIT_TICKS','IO Wait','SYS_TICKS','System','IDLE_TICKS','Idle',
'IDLE_TIME','Idle','BUSY_TIME','Busy','USER_TIME','User','SYS_TIME','System','IOWAIT_TIME','IO Wait','NICE_TIME','Nice',
'Idle','Dunno') name,
		100*(t1.value-t0.value)/totals.tot_x pct
from	v$osstat t1,
		op_os_cpu_snap t0,
		(
			select	sum(x1.value-x0.value) tot_x
			from	v$osstat x1,
					op_os_cpu_snap x0
			where	x1.stat_name = x0.stat_name
			  and	x1.stat_name in ('USER_TICKS','NICE_TICKS','IO_WAIT_TICKS','SYS_TICKS','IDLE_TICKS',
			  					'USER_TIME','SYS_TIME','IDLE_TIME','IOWAIT_TIME','NICE_TIME')
		) totals
where	t1.stat_name = t0.stat_name
  and	t1.stat_name in ('USER_TICKS','NICE_TICKS','IO_WAIT_TICKS','SYS_TICKS','IDLE_TICKS')
/

--prompt
--prompt --- Details
--select 	decode(t1.stat_name,'USER_TICKS','User','NICE_TICKS','Nice','IO_WAIT_TICKS','IO Wait','SYS_TICKS','System','IDLE_TICKS','Idle','Dunno') name,
--		100*(t1.value-t0.value)/totals.tot_ticks pct
--from	v$osstat t1,
--		op_os_cpu_snap t0,
--		(
--			select	sum(x1.value-x0.value) tot_ticks
--			from	v$osstat x1,
--					op_os_cpu_snap x0
--			where	x1.stat_name = x0.stat_name
--			  and	x1.stat_name in ('USER_TICKS','NICE_TICKS','IO_WAIT_TICKS','SYS_TICKS','IDLE_TICKS')
--		) totals
--where	t1.stat_name = t0.stat_name
--  and	t1.stat_name in ('USER_TICKS','NICE_TICKS','IO_WAIT_TICKS','SYS_TICKS','IDLE_TICKS')
--order by 1
--/


start osmclear

