-- ********************************************************************
-- * Copyright Notice  : (c)1998-2016  OraPub, Inc.
-- * Filename          : osm.sql
-- * Author            : Craig Shallahamer, craig@orapub.com
-- * Original          : 24-SEP-98
-- * Last Update       : 15-Feb-2016
-- * Description       : OSM menu
-- * Usage             : start osm.sql
-- ********************************************************************

prompt
prompt OraPub works with Oracle DBAs to take their tuning skills to the next level
prompt 
prompt OraPub System Monitor Toolkit Menu
prompt (c)1998-2016 OraPub, Inc. - Free use, just keep company and author name
prompt 
--prompt -- Object Growth Analysis
--prompt obcrobj  Create object growth objects
--prompt ogbigld  Load selected objects into Object Growth tables (will prompt)
--prompt ogobjset Set object(s) obj growth specifics
--prompt ogdoit   Load growth management data for scheduled objects
--prompt ogwhich  ID object owner and name in dba_objects and o$dba_objects
--prompt ogobjlst List objects in Object Growth schedule
--prompt 
prompt -- Users
prompt cu       Create an Oracle user (<uid> <pwd> <dft tbs> <dft tmp tbs> <prof>)
prompt users    Summary info about Oracle users
prompt tp[8,9]  Top Oracle users/processes (will be prompted)
prompt
prompt -- Configuration and Size
prompt rbs      Rollback configuration details
prompt tss      Tablespace space details
prompt dfl      Database file listing
prompt tsmap    Tablespace map detail (<tbs name>)
prompt stu      Segment types and size per user summary
prompt idx      Index columns (<owner> <table>)
prompt
prompt -- Fragmentation
prompt fgtbl    Table frag (<owner> <tblname>)
prompt fgidx    Index frag (<owner> <INDEX name>)
prompt tbfsum   Table block frag summary (<owner> <table> <min tbf>)
prompt istat    Index statistics (<owner> <index>)
prompt
prompt -- Data Selectivity
prompt ds[7]    Data selectivity for a col(s) (<own> <tbl> <col(s)>)
prompt dsn      Data selectivity for a numeric col(s) (<own> <tbl> <col(s)>)
prompt
prompt -- Instance Parameters
prompt ip       Instance parameters (<partial param value>)
prompt ipx      Instance parameters (hidden also) (<partial param value>)
prompt ipcbc    Instance params realted to the cache buffer chain latches
prompt
prompt -- SGA Size and Activity
prompt sga      System global area summary
prompt spspinfo Shared pool sub-pool information
prompt chr      SGA cache hit ratios (some of them)
prompt clone    Show clone buffers counts
prompt lc       Library cache details
prompt dboc     v$db_object_cache (<min execs> <min size>)
prompt mts      Multi-threaded activity details
prompt
prompt -- Redo Logs
prompt rlog     Redo log activity (v$log)
prompt rdohist  Redo log switching history (v$loghist)
prompt
prompt -- Session Sampling
prompt as       Active session listing (prompts: <sid|%> <sql_id|%>)
prompt rss      Realtime Session Sampler 
prompt .        (<SID_low> <SID_high> <serial_low> <serial_high> <cpu|wait|%> <WE%|%> <delay_sec>)
prompt
prompt -- Instance Statistics
prompt sessinfo[9] Oracle session details / ID (prompted...)
prompt sesstat     v$sysstat details (<sid> <partial name>)
prompt sysstat     v$sysstat details (<partial name>)
prompt sysstatRaw  v$sysstat baseline (<1...5> '<full stat name>') See sysstatbl.sql
prompt sysstatbl   v$sysstat baseline report, calls sysstatRaw
prompt getgcrec    Get RAC interconnect times using GC cr block rec times, format for R
prompt
prompt -- SQL Statements
prompt sqlgettext List SQL statement text <v$sql id column> <id value>
prompt sqlsimfms  List FMS for similar SQL statements (<min sql_id count> <min execs> <sim text>)
prompt sqlgetid   List sql_ids based on FMS (<fms>)
prompt -- SQL Elapsed Times
prompt sqlelget   Get individual SQL elapsed times (<sql id> <plan hash value|full plan hash value> <samples> <delay s>)
prompt sqlelget11 Get individual SQL elapsed times (<sql id> <plan hash value> <max samples> <max loops>)
prompt            sqlelget11 does not use dbms_sleep... but spins on a CPU
prompt -- SQL "Top"
prompt sqls1[8,9] List "top" SQL statements (<min pio> <min lio>)
prompt 
prompt -- IO
prompt dfio     Oracle datafile I/O details
prompt iosum    Oracle IO summary since instance startup 
prompt iosumx   Oracle IO summary for interval between runs, DELTA
prompt
prompt -- Latching/Mutex: Serialization Control
prompt latch[8] Latching statistics
prompt latchx   Latching statistics w/deltas
prompt latchclass   Latch class assignment (must be run as sys)
prompt latchchild   Gather child latch activity (<latch#> <sleep>)
prompt
prompt -- Oracle Time Based Analysis: TT:Total Time, RT:Response Time
prompt ttpctx       TT Profile : instance perspective with out categories (like swpctx.sql)
prompt rtpctx       RT Profile : instance perspective with out categories (like swpctx.sql)
prompt rtc          RT Profile : system perspective using Oracle categories
prompt rtsysx[8]    RT Profile : system perspective DELTA (<interval (sec)>  <# sim SQL chars>)
prompt rtsess[9]    RT Profile : session perspective (9:<sid>,10+:<client ident>)
prompt
prompt -- Oracle Wait Event Analysis
prompt swpct    SW system event percentage summary
prompt swpctx[11] SW system event percentage summary DELTA
prompt swpctidle  Idle only SW system event percentage summary
prompt swpctxidle Idle only SW system event percentage summary DELTA
prompt swswc    SW session wait level w/counts
prompt swswp    SW session wait level w/paramters
prompt swsessid SW session event level for given SID (<sid>)
prompt swsid    SW session wait level for given SID (<sid>)
prompt swsw     SW session wait level; all sessions!
prompt swenq    SW enqueue details
prompt swenqc   SW enqueue details by count
prompt swenqx   SW enqueue detail (<p1>  <p2>)
prompt swname   SW event name and display name (<partial event>)
prompt
prompt -- Wait Time Histogram related scripts and reports, see readmeEventHist.txt
prompt swgettimes  Get individual event occurrence times (<partial event> <samples> <delay s>)
prompt swEhChart.r Create 2 pages of nice histograms based on OSM report output
prompt swEhVdGet   Get v$event_histogram wait times and gen output for swEhChart.r
prompt             (<max_sample_loops>  <min_samples_required>  <wait_event_name>)
prompt swEhAwrGet  Get v$event_histgroam times from AWR (DBA_HIST_) and gen output for swEhChart.r
prompt swhist      Get v$event_hist bin counts. Output can be used with swEhChart.r (<partial event>)
prompt swhistx     Get delta v$event_hist bin counts. Output Can be used with swEhChart.r (<partial event>)
prompt
prompt -- OS CPU Utilization
prompt oscpuutil    OS CPU utilization average
prompt timechk x    Check Oracle's CPU consumption time (v$sysstat based) reporting (<interval>)
prompt
prompt -- Object Details
prompt objloc         Object location listing (<owner> <partial name>)
prompt objfb          Object details for a given file and block (<file#> <blk#>)
prompt bcobjfb        Object details for a ... in cache         (<file#> <blk#>)
prompt
prompt -- Research Helpers
prompt tmcomp         Compare time-based and sample-based (ASH) analysis
prompt mkodo          Create the odometer (odo) table and indexes.
prompt mkodo_ouch     Same, but with a commit after each insert.
prompt cycledb9tx     Cycle the current db instance (O 9,10,11,12) - Be careful!
prompt listeventcodes list all the Oracle event codes (<partial event|" "|dump|etc>)
prompt baseline1      Show a few performance baseline statistics
prompt
prompt -- OSM Management
prompt osmsetvar Must be run before some scripts will work, to init variables
prompt osmprep  Prepare the OSM Interactive environment
prompt osmtitle Standard OSM Interactive title script (other similar scripts)
prompt osmclear Standard OSM Interactive end of script clear stuff
prompt
prompt
prompt OraPub System Monitor - Interactive Analysis Menu
prompt (c)1998-2016 OraPub, Inc. - Free use, just keep company and author name
prompt
prompt OraPub Members have unlimited access to videos and webinars and more
prompt
