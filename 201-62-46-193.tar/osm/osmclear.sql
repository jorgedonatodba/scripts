-- ********************************************************************
-- * Copyright Notice   : (c)1998 OraPub, Inc.
-- * Filename		: osmclear.sql - Version 1.0
-- * Author		: Craig A. Shallahamer
-- * Original		: 24-SEP-98
-- * Last Update	: 05-Dec-2014 - OOI message
-- * Description	: Standard OSM "footer" / clear program
-- * Usage		: start osmclear.sql
-- ********************************************************************

--prompt
--prompt OraPub Online Institute - Because Oracle DBAs can NOT get the training they need.
--prompt

set termout off

clear break
set feedback on
set echo off
ttitle off
set heading on
set pagesize 60
set linesize 80

set termout on
