-- ******************************************************
-- * Copyright Notice   : (c)1998-2014,2015 OraPub, Inc.
-- * Filename           : osmprep.sql 
-- * Author             : Craig A. Shallahamer
-- * Original           : 17-AUG-98
-- * Last Modified      : 23-Dec-2014
-- * Description        : OSM preperation script
-- * Usage              : start osmprep.sql 
-- ******************************************************

prompt 
prompt OraPub System Monitor - Interactive (OSM-I) installation script.
prompt 
prompt (c)1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2008 by OraPub, Inc.
prompt (c)2009,2010,2011,2012,2013,2014,2015 by OraPub, Inc.
prompt 
prompt There is absolutely no guarantee with this software.  You may
prompt use this software at your own risk, not OraPub's risk. 
prompt No value is implied or stated.
prompt
prompt You may need to run $ORACLE_HOME/rdbms/admin/catblock.sql
prompt
prompt Connect as the user who will be using the OSM.
prompt
prompt Press ENTER to continue.
accept x

prompt
prompt Creating interim tables for delta calculations
prompt
-- Just for rtsysx8.sql
drop   table o$sysstat;
create table o$sysstat as select * from v$sysstat where 1=0;
--
drop table system_event_snap;
create table system_event_snap as select * from v$system_event where 1=0;
drop table event_histogram_snap;
create table event_histogram_snap as select * from v$event_histogram where 1=0;
drop table op_sys_time_model_snap;
create table op_sys_time_model_snap as select * from v$sys_time_model where 1=0;
drop table op_os_cpu_snap;
create table op_os_cpu_snap as select stat_name,value from v$osstat where 1=0;

drop table o$system_event_snap;
create table o$system_event_snap as select * from v$system_event where 1=0;

drop table o$sys_time_model;
create table o$sys_time_model as select * from v$sys_time_model where 1=0;

drop   table o$rtsysx_sql;
create table o$rtsysx_sql ( 
  sql_id varchar2(13),sql_address raw(8),cpu_time number, elapsed_time number,
  sorts number, executions number, parse_calls number, disk_reads number,
  buffer_gets number, rows_processed number, sql_text varchar2(1000)
);
create unique index o$rtsysx_sql on o$rtsysx_sql (sql_id);

-- rtsysx8.sql
drop   table o$rtsysx_sql8;
create table o$rtsysx_sql8 ( 
  sql_address raw(8),cpu_time number, elapsed_time number,
  sorts number, executions number, parse_calls number, disk_reads number,
  buffer_gets number, rows_processed number, sql_text varchar2(1000)
);
create unique index o$rtsysx_sql8 on o$rtsysx_sql8 (sql_address);

-- rtcx.sql
drop table o$rtcx_snap;
create table o$rtcx_snap (category varchar2(100),time_cs number, waits number);

-- collection scripts (e.g., rss.sql, ash scripts,) need these two functions

create or replace function get_interval_s_fnc(i_intrvl interval day to second) return number is
begin
  return extract(day from i_intrvl) * 86400 +
         extract(hour from i_intrvl) * 3600 +
         extract(minute from i_intrvl) * 60 +
         extract(second from i_intrvl);
  exception
    when others then begin return null;
  end;
end;
/
--
--create or replace function rss_minutes_ago_fnc( old_time_in timestamp) return number is
--begin
--  return rss_get_interval_s_fnc ( current_timestamp-old_time_in ) / 60 ;
--  exception
--    when others then begin return null;
--  end;
--end;
--/

prompt To categorize wait events for OSM reports, run:
prompt
prompt For pre-10g systems, run event_type_nc.sql
prompt For 10g and beyond, run event_type.sql

prompt
prompt Once you cateogrize the wait events, the installation is complete.
prompt
prompt Menu is osmi.sql 
prompt
prompt ENJOY!!
prompt
