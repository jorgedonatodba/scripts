------------------------------------------------------------
-- file		osmsetvar.sql
-- desc		Set and RESET OSM variables
-- author	Craig A. Shallahamer, craig@orapub.com
-- orig		18-July-2015
-- lst upt	12-Jan-2017 
-- copyright (c)2015,2017 OraPub, Inc.
--
-- @osmsetvar must be run to init variables

variable oscpuutil_idle_v		number;
variable oscpuutil_busy_v		number;
variable oscpuutil_util_v		number;
variable oscpuutil_m_v			number;
variable oscpuutil_sssss_v		number;

variable sysstatbl_v1			number;
variable sysstatbl_v2			number;
variable sysstatbl_v3			number;
variable sysstatbl_v4			number;
variable sysstatbl_v5			number;
variable sysstatbl_v6			number;
variable sysstatbl_v7			number;
variable sysstatbl_v8			number;
variable sysstatbl_v9			number;
variable sysstatbl_v10			number;
variable sysstatbl_v11			number;

variable sysstatbl_sssss_v1		number;
variable sysstatbl_sssss_v2		number;
variable sysstatbl_sssss_v3		number;
variable sysstatbl_sssss_v4		number;
variable sysstatbl_sssss_v5		number;
variable sysstatbl_sssss_v6		number;
variable sysstatbl_sssss_v7		number;
variable sysstatbl_sssss_v8		number;
variable sysstatbl_sssss_v9		number;
variable sysstatbl_sssss_v10		number;
variable sysstatbl_sssss_v11		number;

variable tcomp_db_cpu_s_v		number;
variable tcomp_db_time_s_v		number;
variable tcomp_tot_wait_s_v		number;
variable tcomp_ash_last_sample_id_v number;
begin
	:tcomp_ash_last_sample_id_v := 1 ;
end;
/
variable tcomp_ash_cpu_count_v	number;
variable tcomp_ash_wait_count_v	number;
variable stamp_time_v			varchar2(50);
begin
  	select	to_char(systimestamp,'YYYY-Mon-DD HH24:MI:SSxFF')
	into	:stamp_time_v
	from	dual;
end;
/
prompt OSM variables re-set
