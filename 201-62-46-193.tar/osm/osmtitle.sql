-- ********************************************************************
-- * Copyright Notice   : (c)1998,2010 OraPub, Inc.
-- * Filename		: osmtitle.sql 
-- * Author		: Craig A. Shallahamer
-- * Original		: 17-AUG-98
-- * Last Update	: 12-Aug-2015
-- * Description	: Standard OSM title header
-- * Usage		: start osmtitle.sql
-- ********************************************************************

set termout off
set tab off

break on today
col today new_value now
select to_char(sysdate, 'DD-Mon HH:MIam') today 
from   dual;

col valZ new_value db noprint
select value valZ 
from   v$parameter 
where  name = 'db_name';

col valZ new_value inst noprint
select value valZ 
from   v$parameter 
where  name = 'instance_name';

clear breaks
set termout on
set heading on
set linesize 80

ttitle -
    left 'DB/Inst: &db/&inst'        right now              skip 0 -
    left 'Report:   &osm_prog'  center 'OSM by OraPub, Inc.' - 
    right 'Page' sql.pno                               skip 1 -
    center '&osm_title'                                skip 2
