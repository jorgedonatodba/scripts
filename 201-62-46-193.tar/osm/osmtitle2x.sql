-- ********************************************************************
-- * Copyright Notice   : (c)2014 OraPub, Inc.
-- * Filename		: osmtitle2x.sql  - Two line title and define line size
-- * Author		: Craig A. Shallahamer
-- * Original		: 27-Nov-2014
-- * Last Update	: 12-Aug-2015
-- * Description	: Standard OSM title header but with 2 lines and define line size
-- * Usage		: start osmtitle2x.sql 159
-- ********************************************************************

def lsize=&1

set termout off
set tab off

break on today
col today new_value now
select to_char(sysdate, 'DD-Mon HH:MIam') today 
from   dual;

col valZ new_value db noprint
select value valZ 
from   v$parameter 
where  name = 'db_name';

col valZ new_value inst noprint
select value valZ 
from   v$parameter 
where  name = 'instance_name';

clear breaks
set termout on
set heading on
set linesize &lsize

ttitle -
    left 'DB/Inst: &db/&inst'        right now              skip 0 -
    left 'Report:   &osm_prog'  center 'OSM by OraPub, Inc.' - 
    right 'Page' sql.pno                               skip 2 -
    center '&osm_title1'                                skip 1 -
    center '&osm_title2'                                skip 2
