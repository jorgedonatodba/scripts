-- ********************************************************************
-- * Copyright Notice   : (c)2002,2008 OraPub, Inc.
-- * Filename		: osmtitlell.sql 
-- * Author		: Craig A. Shallahamer
-- * Original		: 04-Jan-2008
-- * Last Update	: 1-Sep-2015
-- * Description	: Long-Long OSM title header
-- * Usage		: start osmtitlell.sql
-- ********************************************************************

set termout off

set tab off

break on today
col today new_value now
select to_char(sysdate, 'DD-Mon HH:MIam') today 
from   dual;

col val1 new_value db noprint
select value val1 
from   v$parameter 
where  name = 'db_name';

col valZ new_value inst noprint
select value valZ 
from   v$parameter 
where  name = 'instance_name';

clear breaks
set termout on
set heading on
set linesize 200

ttitle -
    left 'DB/Inst: &db/&inst'        right now              skip 0 -
    left 'Report:   &osm_prog'  center 'OSM by OraPub, Inc.' - 
    right 'Page' sql.pno                               skip 1 -
    center '&osm_title'                                skip 1 -
    center '&osm_title2'                                skip 2
