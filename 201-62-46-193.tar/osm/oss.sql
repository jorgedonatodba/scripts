

set echo off verify off heading off

def sid=&1
def state=&2
def delay=&3

prompt Reltime Session Sampler - collection and display.
prompt Session ID &sid in a &state state every &delay second(s)
prompt To realtime stream output, do: tail -f /tmp/oss_sql.txt
prompt
accept x prompt "To begin press ENTER. Otherwise break out now."

create or replace function oss_get_interval_s_fnc(i_intrvl interval day to second) return number is
begin
  return extract(day from i_intrvl) * 86400 + 
         extract(hour from i_intrvl) * 3600 + 
         extract(minute from i_intrvl) * 60 + 
         extract(second from i_intrvl);
  exception
    when others then begin return null; 
  end;
end;
/

create or replace function oss_minutes_ago_fnc( old_time_in timestamp) return number is
begin
  return oss_get_interval_s_fnc ( current_timestamp-old_time_in ) / 60 ;
  exception
    when others then begin return null; 
  end;
end;
/

create or replace directory temp_dir as '/tmp';

prompt Sampling started...

set serveroutput on

begin
declare
  fHandle  UTL_FILE.FILE_TYPE;

  next_sample_time_ts_var       timestamp;

  current_timestamp_v timestamp;
  username_v varchar2(30);
  state_v varchar2(19);
  event_v varchar2(64);
  sql_id_v varchar2(13);
  p1_v number;
  p2_v number;
  p3_v number;

begin
  dbms_session.set_identifier('osm:i oss.sql');

  fHandle := UTL_FILE.FOPEN('TEMP_DIR', 'oss_sql.txt', 'W');

  UTL_FILE.PUT_LINE(fHandle, 'Starting sampling...');
  utl_file.fflush(fHandle);

  while 1 = 1
  loop


    select current_timestamp + interval '0 00:00:&delay' day to second
    into   next_sample_time_ts_var
    from   dual;

    begin

      select
       current_timestamp,
                username,                      
                decode(state,'WAITING','WAIT','CPU'),
                sql_id                        ,
                decode(state,'WAITING',event,'') ,
                decode(state,'WAITING',p1,''),
                decode(state,'WAITING',p2,''),
                decode(state,'WAITING',p3,'')
        into   
current_timestamp_v, 
username_v,
state_v,
sql_id_v,
event_v,
p1_v, p2_v, p3_v
        from   v$session
        where  sid = &sid
          and  decode(state,'WAITING','WAIT','CPU') like '&state%';

      UTL_FILE.PUT_LINE(fHandle, to_char(current_timestamp_v,'HH24:MI:SS:FF3')||' '||username_v||' '||state_v||' '||sql_id_v||' '||event_v||' '||p1_v||' '||p2_v||' '||p3_v);
      utl_file.fflush(fHandle);

      EXCEPTION when others then
	null;
      end;


      dbms_lock.sleep( greatest( oss_get_interval_s_fnc( next_sample_time_ts_var - current_timestamp ),0));

  end loop;
  UTL_FILE.PUT_LINE(fHandle, 'Ending sampling...');
  UTL_FILE.FCLOSE(fHandle);
end;
end;
/


