
select
    spid, stid, program, background
from
    V$process
where
    spid != stid
and spid in (
        select spid
        from v$process
        group by spid
        having count(*) > 1
    )
order by
    spid, stid, program
;
