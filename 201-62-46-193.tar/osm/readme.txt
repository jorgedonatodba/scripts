Last Updated 27-July-2015
(c)1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2011,2013,2014,2015 OraPub, Inc.

-------------------------------------------------------------------
Welcome to the OraPub System Monitor... the OSM Toolkit.
-------------------------------------------------------------------

!! There are no warrenties or guarenties!  Use at your own risk! !!

The objective of this toolkit is to help make it easier to properly
performance a quantiative Oracle time-based or sample-based anlaysis.
In short... make Oracle system run super fast!

You need to know:

* Details on Wait Time Histogram relates scripts, see readmeEventHist.txt

* All ASH scripts have been consolidated into the BloodHound Toolkit. Do an
  OraPub.com search for "blood" and you'll see it. It's FREE.

To install: Four Simple Steps
-----------

1. Unload software:
---
  
  Place the archive in the directory <somthing>.  For example,
  $ORACLE_BASE/local.  

  When the software is unarchived, the interactive and historical subdirctories
  will automatically be created.

  The OSM directory structure is:

  <something>/osm

  $ cd $ORACLE_BASE/local
  $ tar xvf osm<ver>.tar

2. Setup your O/S environment.
---

  UNIX:  For example, include these lines in your Bourne shell .profile file.

  OSM_BASE=<something>/osm
  PATH=$OSM_BASE:$PATH
  ORACLE_PATH=$OSM_BASE:$ORACLE_PATH
  export OSM_BASE PATH ORACLE_PATH
  
3. Get permission
---
  - The "osm" user only needs to select from the v$ and DBA_ views
    and create a few tables for interium storage.  The role of OEM should do it
    and of course granting DBA will also do it.

  - The sleep function is be called in some scripts, if you want to use these
    scripts ensure the "osm" user can do:

	SQL> exec sys.dbms_lock.sleep(5);

    If not, than grant execute on dbms_lock to "osm";

  - Run "prep" script.  Examine the script...it's simple. If you are OK with it,
    then Login into SQL*Plus as the "osm" user and run osmprep.sql.
    
4. Menu for all tools
---

   IMPORTANT: To see the OSM menu, from within SQL*Plus, run osm.sql.  

That's it! Have fun!

--end--

