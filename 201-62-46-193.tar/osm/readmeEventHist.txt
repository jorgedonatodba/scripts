file 	readmeEventHist.txt author	Craig Shallahamer
(craig@orapub.com orig	4-May-2015 update	28-July-2015

Introduction
-----------------------------------------------------

This file contains details about how to capture and report Oracle
wait event times from a variety of sources/methods to then
generate statistics and a number of histograms using the free
statistical package R (r-project.org).

To understand the value of these scripts please search my blog,
watch my webinars and watch my online video seminar entititled,
Using Skewed Performance Data To Your Advantage.

Details -----------------------------------------------------

The OSM toolkit contains a number tools to help you understand
Oracle wait event times. While it is easy to get the average wait
even time, it is NOT easy to retreive and to understand invidual
wait occurances.

There are many ways to get indiviual wait event time occurance
information; frequent sampling of v$system_event, querying
v$event_histogram and from the AWR table
dba_hist_event_histogram. I have created scripts to aid in
collecting and formatting the output for direct copy and paste
into an R script.

Here is a quick description of each script and their pros and
cons. Also, inside each script is detailed documentation about
how to use the script.

swgettime.sql

directly samples from v$system_event. If the sleep time between
sampling is short, you can sometimes get indivual occurrance wait
times. Perfect! However, short or zero sleep times will consume
CPU cycles. A zero sleep time will essentially grab hold of a CPU
core and not let go. That's OK if you have the available CPU
capacity.

	The output can be pasted into an R script to do additional
	analysis. This output is NOT meant to be directly pasted into
	the swEhCharts.r script presented below. It's because the
	script produce individual wait event occurrance times, not
	summarization based on v$event_histogram. Search my blog
	about how create a histogram in R and you'll be set...easy.

swEhCharts.r

is the R script from which all three of the below script outputs
can be copy and pasted. It is fairly well self documented. Upon
pasting the appropriate output into the script and then pasting
swEhCharts.r into R, R will produce some basic statistics (e.g.,
mean, median, max) and create eight histograms focusing on
different aspects of the data. Very cool!

	The histograms are "proper histograms" because the bin
	(horizontal axis) sizes are uniform. This is NOT the case
	when you simply create a histogram from v$event_histogram
	data. Doing so can mislead us because we visually expect the
	bins to be uniform. If you look closely at the event
	histogram bin sizes in OEM, you will notice they are not
	uniform...bad.

	Keep in mind that the histogram data I generate is based on
	the event_histogram bin counts. So the detailed data (event
	times) are the not actual individual wait times. Instead,
	they are generated based on the bin counts. For example,
	suppose the >1ms to <=2ms bin has a count of 500000. I
	essentially create 500000 (uniform) random values between
	1.0000001 ms and 2ms. There is no way the real values were
	actually uniformally random between 1ms and 2ms, but that's
	the best method I could come up with. But certainly, this is
	better than creating a histogram with non-uniform bin sizes!

swEhAwrGet.sql

retreives event histogram data from the AWR table
dba_event_histogram, which is based on v$event_histogram. You are
prompted for the classic AWR inputs such as DBID but also the
wait event you are interested in. The script will then produce
the R code to then be pasted into swEhCharts.r. This script fast,
simple and works great!

swEhVdGet.sql

retreives v$event_histogram data and then produces the R code to
then be pasted into swEhCharts.r. This script is unique becasue
it was designed to be directly pasted into SQL*Plus in a live and
hostile DBA production enviornment. This means, there is NO DDL,
NO DML, DBMS_LOCK.SLEEP is not used and there are multiple ways
to envoke this script. For example you can simply run it on the
command line with OR without parameters OR you can copy/paste
most of the script code directly into sqlpus.

	This script is very well self-documented. Please take a look
	before using.

	Because dbms_lock.sleep is not used to pause between sample
	collection, this script NEVER sleeps. This means it will
	likely consume an entire CPU core. It is YOUR RESPONSIBILITY
	to ensure there is available CPU capacity.

Enjoy!

---END
