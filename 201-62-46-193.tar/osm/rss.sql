-- ******************************************************
-- * Copyright Notice   : (c)2014 OraPub, Inc.
-- * Filename           : rss.sql - Realtime Session Sampler
-- * Author             : Craig A. Shallahamer
-- * Original           : 07-Jun-2014
-- * Last Modified      : 15-Jul-2014
-- * Description        : Collect and display session activity in realtime
-- * Usage : @rss sid_low sid_high serial#_low serial#_high cpu|wait|% event%|% delay_s
-- *         @rss 0 999999 0 999999 % % 1
-- *         @rss 0 999999 0 999999 cpu % 1
-- *         @rss 0 999999 0 999999 wait % 1
-- *         @rss 0 999999 0 999999 wait db%file%seq% 1
-- *         @rss 328 328 1 1 % % 0.25
-- ******************************************************

set echo off verify off heading off
--set echo on verify on heading on

def sidLow=&1
def sidHigh=&2
def serLow=&3
def serHigh=&4
def state=&5
def wePartial=&6
def delay=&7

prompt OraPub Realtime Session Sampler - collection and display
prompt
prompt Every &delay second(s), session ID from &sidLow to &sidHigh and serial# from &serLow to &serHigh
prompt in a &state state will be sampled and displayed.
prompt When waiting, only display when wait event is like &wePartial
prompt 
prompt Output will be written to the /tmp/rss_sql.txt file.
prompt To stream output in realtime, in another window do: tail -f /tmp/rss_sql.txt
prompt
accept x prompt "To begin sampling press ENTER. Otherwise break out now."

create or replace directory temp_dir as '/tmp';

prompt To stop sampling, break out (e.g., CNTRL-C)
prompt
prompt Sampling started...

set serveroutput on

begin
declare
  type cv_typ is ref cursor;
  cv cv_typ;
  sql_to_run_v varchar2(999);

  fHandle  UTL_FILE.FILE_TYPE;

  cntr_v number;
  next_sample_time_ts_var       timestamp;

  current_timestamp_v timestamp;
  sid_v number;
  serial#_v number;
  username_v varchar2(30);
  state_v varchar2(19);
  event_v varchar2(64);
  wecat_v varchar2(64);
  sql_id_v varchar2(13);
  p1_v number;
  p2_v number;
  p3_v number;

begin
  dbms_session.set_identifier('osm:i rss.sql');

  fHandle := UTL_FILE.FOPEN('TEMP_DIR', 'rss_sql.txt', 'W');

  UTL_FILE.PUT_LINE(fHandle, 'Starting sampling...');
  utl_file.fflush(fHandle);

  cntr_v := 0;

  while 1 = 1
  loop

    cntr_v := cntr_v + 1;

    select current_timestamp + interval '0 00:00:&delay' day to second
    into   next_sample_time_ts_var
    from   dual;

    begin

      open cv for
		select
				current_timestamp,
				sid,
				serial#,
				decode(username,'','-',username),
				decode(state,'WAITING','WAIT','CPU '),
				nvl(sql_id,'-'),
				decode(state,'WAITING',decode(o.type,'bogus','idle',o.type),'-'),
				decode(state,'WAITING',vs.event,'-') ,
				decode(state,'WAITING',p1,''),
				decode(state,'WAITING',p2,''),
				decode(state,'WAITING',p3,'')
        from	v$session vs,
				o$event_type o
        where	sid between &sidLow and &sidHigh
          and	serial# between &serLow and &serHigh
          and	decode(state,'WAITING','WAIT','CPU') like upper('&state%')
		  and	vs.event like '&wePartial%'
		  and	vs.event = o.event(+)
		  and	o.type != 'bogus';

		loop
			fetch cv into
				current_timestamp_v, 
				sid_v,
				serial#_v,
				username_v,
				state_v,
				sql_id_v,
				wecat_v,
				event_v,
				p1_v, p2_v, p3_v
	  		;
	  exit when cv%NOTFOUND;

          UTL_FILE.PUT_LINE(fHandle, lpad(trim(cntr_v),3,' ')||' '|| to_char(current_timestamp_v,'HH24:MI:SS:FF3')||' '||lpad(trim( sid_v ),5,' ')||lpad(trim(serial#_v),6,' ')||' '||lpad(trim(username_v),10,' ')||' '||state_v||' '||rpad(trim(sql_id_v),20,' ')||' '||rpad(trim(wecat_v),5,' ')||' '||rpad(trim(event_v),30,' ')||' ['||p1_v||','||p2_v||','||p3_v||']');
          utl_file.fflush(fHandle);

      end loop;

      EXCEPTION when others then
        cntr_v := cntr_v + 1;
      end;

      dbms_lock.sleep( greatest( get_interval_s_fnc( next_sample_time_ts_var - current_timestamp ),0));

  end loop;
  UTL_FILE.PUT_LINE(fHandle, 'Ending sampling...');
  UTL_FILE.FCLOSE(fHandle);
end;
end;
/


