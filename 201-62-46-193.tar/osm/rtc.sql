------------------------------------------------------------
-- file		rtc.sql
-- desc		Oracle response time CATEGORY statitics percentage reporting.
-- author	Craig A. Shallahamer, craig@orapub.com
-- orig		04-Jan-2008
-- lst upt	04-Jan-2008 
-- copyright	(c)2008 OraPub, Inc.

-- It is possible to get percentages greater/lesser than 100% because there
-- is a time lag between the total calculations (which queries
-- from v$system_event and v$sysstat) and the report query (which also queries from
-- v$system_event and v$sysstat).
------------------------------------------------------------

set echo off
set feedback off
set heading off
set verify off
set termout off

col wc format a15 heading "Wait Class"
col time_wait_m format 999,999,990 heading "Time Waited|(min)"
col pct_wait format 990 heading "% Time|Waited"
col avg_wait_ms format 9990.0 heading "Avg Time|Waited (ms)"

col val1 new_val tot_time_waited 

select a.time+b.time val1
from
	(
	select	sum(time_waited) time
	from	v$system_event se,
			v$event_name en
	where 	se.event = en.name
	  and 	en.wait_class != 'Idle'
	) a,
	(
	select	value time
	from 	v$sysstat
	where 	statistic#=12
	) b
/

set echo off
set feedback off
set heading on
set verify off
set termout on

def osm_prog	= 'rtc.sql'
def osm_title	= 'System Response Time (red line, Oracle categories) Activity By PERCENT'

start osmtitle

select	en.wait_class wc,
		sum(time_waited)/100/60 time_wait_m,
		100*(sum(time_waited)/&tot_time_waited) pct_wait,
		(avg(average_wait)/100)*1000 avg_wait_ms
from 	v$system_event se,
		v$event_name en
where 	se.event = en.name
  and 	en.wait_class != 'Idle'
group by en.wait_class
UNION
select 'CPU wait + used' wc,
		value/100/60 time_wait_m,
		100*(value/&tot_time_waited) pct_wait,
		0 avg_wait_ms
from 	v$sysstat
where 	statistic#=12
order by 2 desc
/

start osmclear


