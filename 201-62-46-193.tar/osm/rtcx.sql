------------------------------------------------------------
-- file		rtcx.sql
-- desc		Oracle response time CATEGORY statitics percentage reporting.
-- author	Craig A. Shallahamer, craig@orapub.com
-- orig		04-Jan-2008
-- lst upt	14-Jan-2008 
-- copyright	(c)2008 OraPub, Inc.

-- It is possible to get percentages greater/lesser than 100% because there
-- is a time lag between the total calculations (which queries
-- from v$system_event and v$sysstat) and the report query (which also queries from
-- v$system_event and v$sysstat).
------------------------------------------------------------

prompt Remember: This report must be run twice so both the initial and
prompt final values are available. If no output, press ENTER twice.

set echo off
set feedback off
set heading off
set verify off
set termout off

col val1 new_val tot_delta_time_cs 
select 	
	sum(b.time_cs-a.time_cs) val1
from (
	select 	category,time_cs,waits
	from	o$rtcx_snap
     ) a,
     (
	select	en.wait_class category,
		sum(time_waited) time_cs,
		sum(total_waits) waits
	from 	v$system_event se,
		v$event_name en
	where 	se.event = en.name
  	and 	en.wait_class != 'Idle'
	group by en.wait_class
	UNION
	select 'CPU wait + used' category,
		value time_cs,
		0 waits
	from 	v$sysstat
	where 	statistic#=12
     ) b
where a.category = b.category
/

set echo off
set feedback off
set heading on
set verify off
set termout on

def osm_prog	= 'rtcx.sql'
def osm_title	= 'System Response Time (blue line, Oracle categories) Activity By PERCENT'

start osmtitle

col category format a30 heading "Wait Class"
col tot_time_delta format 999,990.0 heading "Total|Wait Time|(s)"
col tot_waits_delta format 999,990 heading "Total Waits"
col avg_time_delta format 999,990.0 heading "Avg|Wait Time|(ms)"
col pct_time format 990.00 heading "Pct|Wait Time"

select 	b.category,
	100*((b.time_cs-a.time_cs)/&tot_delta_time_cs) pct_time,
	10*((b.time_cs-a.time_cs)/(b.waits-a.waits+0.00000000001)) avg_time_delta,
	(b.time_cs-a.time_cs)/100 tot_time_delta,
	(b.waits-a.waits+0.000000000001) tot_waits_delta
from (
	select 	category,time_cs,waits
	from	o$rtcx_snap
     ) a,
     (
select	en.wait_class category,
		sum(time_waited) time_cs,
		sum(total_waits) waits
from 	v$system_event se,
	v$event_name en
where 	se.event = en.name
  and 	en.wait_class != 'Idle'
group by en.wait_class
UNION
select 'CPU wait + used' category,
		value time_cs,
		0 waits
from 	v$sysstat
where 	statistic#=12
     ) b
where a.category = b.category
order by 2 desc
/


-- Prepare for the possibility of another run, i.e., store t0 values.
truncate table o$rtcx_snap
/
insert /*+ APPEND */ into o$rtcx_snap nologging
select	en.wait_class category,sum(time_waited) time_cs,sum(total_waits) waits
from 	v$system_event se,
		v$event_name en
where 	se.event = en.name
  and 	en.wait_class != 'Idle'
group by en.wait_class
UNION
select 'CPU wait + used' category,
		value time_cs,0 waits
from 	v$sysstat
where 	statistic#=12
/
commit;

start osmclear

