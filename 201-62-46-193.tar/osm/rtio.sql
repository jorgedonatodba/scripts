-- ********************************************************************
-- * Copyright Notice   : (c)2001 OraPub, Inc.
-- * Filename           : rtio.sql
-- * Author             : Craig A. Shallahamer
-- * Original           : 10-may-01
-- * Last Update        : 24-sep-01
-- * Description        : rtio.sql - Response Time I/O Summary w/Event 
-- *                                 Details (interactive - System Level)
-- * Usage              : start latch.sql
-- ********************************************************************


prompt
prompt rtio.sql - Response Time I/O Summary w/Event Details (interactive - System Level)
prompt

set linesize 150

set feedback off

col cpr   format  90.00 heading "%|CPU|RT|[cpu/rt]"
col wpr   format  90.00 heading "%|Wait|RT|[tw/rt]"
col et    format 999,999,999 heading "Elapsed|Time(min)|[rt+idle]"
col rt    format   9,999,999 heading "Response|Time(min)|[rt=cpu+tw]"
col it    format 999,999,999 heading "Idle|Time(min)|[idle]"
col ctt   format     999,999 heading "CPU|Time|(min)|[cpu]"
col wtt   format     999,999 heading "Tot Wait|Time|(min)|[tw=iot+ow]"
col iwt   format     999,999 heading "IO Wait|Time|(min)|[iot=iow+ior]"
col pctio format      990.00 heading "% IO|Wait Time|[iow/tw]"
col iow   format     999,999 heading "IO Write|Wait Time|(min)|[iow]"
col ior   format     999,999 heading "IO Read| Wait Time|(min)|[ior]"
col owt   format     999,999 heading "Other Wait|Time|(min)|[ow]"

col dte   format a12         heading "Date"
col key   format 999         heading "OSM|Key"

select
        cpu_pct_resp cpr,
        wait_pct_resp wpr,
        wait_time_tot/60 wtt,
        io_wtime_tot_sec/60 iwt,
        100*io_wtime_tot_sec/wait_time_tot pctio,
        io_wtime_write_sec/60 iow,
        io_wtime_read_sec/60 ior,
        other_wtime_sec/60 owt
from
        o$i_rt_sum,
        o$i_io_wtime_write_sec,
        o$i_io_wtime_read_sec
where   rownum = 1
/


col eve   format     a45     heading "IO Wait Event"
col wtt   format     999,999 heading "Tot Wait|Time|(min)"

select
        event eve,
        io_wtime_events_sec/60 wtt
from
        o$i_io_wtime_events_sec
where
  	io_wtime_events_sec > 30
order by io_wtime_events_sec desc
/


set linesize 80





