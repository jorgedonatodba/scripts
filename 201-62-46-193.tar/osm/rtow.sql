-- ********************************************************************
-- * Copyright Notice   : (c)2001 OraPub, Inc.
-- * Filename           : rtow.sql
-- * Author             : Craig A. Shallahamer
-- * Original           : 10-may-01
-- * Last Update        : 10-may-01
-- * Description        : rtow.sql - Response Time Other Waits (non-I/O) 
-- *                                 Event Detail (interactive - system level)
-- * Usage              : start rtow.sql
-- ********************************************************************

prompt
prompt rtow.sql - Response Time Other Waits (non-I/O) Event Detail (interactive - system level)
prompt

col eve   format     a45     heading "Non IO (other) Wait Event"
col wtt   format     999,999 heading "Tot Wait|Time|(min)"

select
        event eve,
        other_wtime_events_sec/60 wtt
from
        o$i_other_wtime_events_sec
where
  	other_wtime_events_sec > 30
order by other_wtime_events_sec desc
/


