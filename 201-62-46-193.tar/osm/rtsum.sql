-- ********************************************************************
-- * Copyright Notice   : (c)2001 OraPub, Inc.
-- * Filename           : rtsum.sql
-- * Author             : Craig A. Shallahamer
-- * Original           : 10-may-01
-- * Last Update        : 24-sep-01
-- * Description        : rtsum.sql - Response Time Summary 
-- *                                  (interactive - system level)
-- * Usage              : start rtsum.sql
-- ********************************************************************

prompt
prompt rtsum.sql - Response Time Summary (interactive - system level)
prompt

col cpr   format       90.00 heading "%|CPU|RT|[cpu/resp]"
col wpr   format       90.00 heading "%|Wait|RT|[tw/resp]"
col et    format 999,999,999 heading "Elapsed|Time(min)|[resp+idle]"
col it    format 999,999,999 heading "Idle|Time(min)|[idle]"
col rt    format   9,999,999 heading "Response|Time(min)|[resp=cpu+tw]"
col ctt   format   9,999,999 heading "CPU|Time|(min)|[cpu]"
col wtt   format     999,999 heading "Tot Wait|Time|(min)|[tw=iow+ow]"
col iwt   format     999,999 heading "IO Wait|Time|(min)|[iow]"
col owt   format     999,999 heading "Other Wait|Time|(min)|[ow]"

set linesize 150

SELECT	
	cpu_pct_resp cpr,
	wait_pct_resp wpr,
	elapsed_time_sec/60 et,
	idle_time_sec/60 it,
	response_time_sec/60 rt,
	cpu_time_tot_sec/60 ctt,
	wait_time_tot/60 wtt,
	io_wtime_tot_sec/60 iwt,
	other_wtime_sec/60 owt
FROM	
	o$i_rt_sum
/

set linesize 80


