-- ********************************************************************
-- * Copyright Notice   : (c)2001,2002 OraPub, Inc.
-- * Filename           : rtsys.sql
-- * Author             : Craig A. Shallahamer
-- * Original           : 10-may-01
-- * Last Update        : 12-jul-03
-- * Description        : rtsys.sql - DRIVER Response Time Summary 
-- *                                  (interactive - system level)
-- * Usage              : start rtsys.sql
-- ********************************************************************

set feedback off

start snap_stats.sql

col rtr   format     990.000 heading "Response Time Ratio"

select
	greatest(cpu_time_tot_sec/cpu_capacity_sec,wait_time_tot/response_time_sec) rtr
from
	o$i_rt_sum
/

start rtsum.sql  -- overall summary
start rtio.sql   -- I/O summary w/event details
start rtow.sql   -- Other waits event details
