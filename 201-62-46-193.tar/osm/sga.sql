-- ********************************************************************
-- * Copyright Notice   : (c)1998,2002 OraPub, Inc.
-- * Filename		: sga 
-- * Author		: Craig A. Shallahamer
-- * Original		: 17-AUG-98
-- * Last Update	: 20-AUG-02
-- * Description	: Show very basic SGA information
-- * Usage		: start sga.sql
-- ********************************************************************

def osm_prog	= 'sga.sql'
def osm_title	= 'System Global Area Summary'
start osmtitle

comp sum of value on report 
break on report 

col comp  format            a20 heading 'Component' justify c trunc
col value format 99,999,999,990 heading 'Size'      justify c trunc

select
  pool comp,
  sum(bytes) value
from
  v$sgastat
where pool != ' '
group by pool
union
select name comp, sum(bytes) value
from   v$sgastat
where name in ('fixed_sga','buffer_cache','log_buffer')
group by name
/

start osmclear

