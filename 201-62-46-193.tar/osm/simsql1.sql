-- This script has been replaced by other similar sql scripts
--
-- ********************************************************************
-- * Copyright Notice   : (c)2004 OraPub, Inc.
-- * Filename		: simsql1.sql 
-- * Author		: Craig A. Shallahamer
-- * Original		: 07-May-04
-- * Last Update	: 
-- * Description	: Identify similar SQL statements that could perhaps
-- * 			  benefit from using bind variables or cursor sharing
-- * Usage		: start simsql.sql <chars to consider>
-- ********************************************************************

def chars=&&1

def osm_prog    = 'simsql1.sql'
def osm_title   = 'Identify Similar SQL Statements (first &chars characters)'

col stmt        heading 'SQL Statement (up to 70 chars)'   format          a70
col the_count   heading 'Count'                 	   format      999,990

start osmtitle

col x noprint

select
  substr(sql_text,1,&chars)       stmt,
  count(*)			  the_count
from
  v$sqlarea 
group by substr(sql_text,1,&chars)
having count(*) > 1
order by 2 desc
/

undef chars

start osmclear


