-- This script has be replaced by the other similar sql scripts
--
-- ********************************************************************
-- * Copyright Notice   : (c)2004 OraPub, Inc.
-- * Filename		: simsql2.sql 
-- * Author		: Craig A. Shallahamer
-- * Original		: 07-May-04
-- * Last Update	: 
-- * Description	: Show SQL that is similar and possible candidate
-- *			  using bind variables and/or cursor sharing.
-- * Usage		: start simsql2.sql '<beginning X chars of SQL>'
-- ********************************************************************

def text='&&1'

def osm_prog    = 'simsql2.sql'
def osm_title   = 'Show Similar SQL Statements'

col stmt        heading 'SQL Statement (first 85 chars)'   format          a85
col address     heading 'Address'                 	   format          a12
col exe         heading 'EXEs'                 	           format          999,990

start osmtitlem

select
  substr(sql_text,1,85)       stmt,
  address		      address,
  executions		      exe
from
  v$sqlarea 
where
  sql_text like '&text%'
order by
  executions desc
/

undef text

start osmclear


