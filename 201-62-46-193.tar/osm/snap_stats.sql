--
-- File:	snap_stats.sql
-- Author:	craig Shallahamer (craig@orapub.com)
-- Orig Date:	7-Oct-2005
-- Last Update:	13-Mar-2006
--

set termout off

drop table o$i_system_event;
create table o$i_system_event as select * from v$system_event nologging;

drop table o$sysstat;
create table o$sysstat as select * from v$sysstat nologging;

drop table o$parameter;
create table o$parameter as select * from v$parameter nologging;

drop table o$instance;
create table o$instance as select * from v$instance nologging;

set termout on

