-- ********************************************************************
-- * Copyright Notice   : (c)2009 OraPub, Inc.
-- * Filename           : spspinfo.sql 
-- * Author             : Craig A. Shallahamer
-- * Original           : 28-APR-09
-- * Last Update        : 28-APR-09
-- * Description        : Show basic shared pool sub-pool information
-- * Usage              : start spspinfo.sql
-- ********************************************************************

col sp_size     format 999,990 heading "SP Size (MB)"
col no_sp       format      90 heading "Num of SPs"
col param       format a20
col value       format a5

set echo on

select sum(bytes/1024/1024) sp_size
from   v$sgastat
where  pool='shared pool';
select count(*) no_sp from x$kghlu;
select INST_ID, KSMDSIDX, KSMSSLEN 
from   x$ksmss 
where  ksmssnam='free memory';
select i.ksppinm param,v.ksppstvl value
from   x$ksppi i, x$ksppcv v
where  v.indx=i.indx
  and  v.inst_id=i.inst_id
  and  i.ksppinm='_kghdsidx_count';

set echo off
start osmclear

