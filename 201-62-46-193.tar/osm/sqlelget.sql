------------------------------------------------------------
-- file         sqlelget.sql 
-- desc         Get 12c SQL elapsed time for a given SQL_ID and Plan Hash Value
-- author       Craig A. Shallahamer, craig@orapub.com
-- orig         01-may-2014
-- lst upt      02-jun-2014 
-- copyright    (c)2014 OraPub, Inc.
-- usage        sqlelget.sql SQL_ID FULL_PLAN_HASH_VALUE|PLAN_HASH_VALUE SAMPLES_TO_GET SAMPLE_DELAY_S
-- usage        Both the full_plan_hash_value or the plan_hash_value can be used
-- usage        sqlelget.sql 9gm93sw7hq936 3760015341 50 0.25
-- Get high execution sql 12c+: select sql_id, full_plan_hash_value, executions, elapsed_time from v$sql order by 3,1,2
------------------------------------------------------------

def sql_id_in=&1
def fphv_in=&2
def samples_in=&3
def delay_in=&4

set echo off
set feedback off
set heading off
set verify off

prompt
prompt Dropping/creating the op_elapsed_samples table...
drop   table op_elapsed_samples;
create table op_elapsed_samples ( samples number, sample_time_ms number );

prompt Starting to collect &samples_in samples with a &delay_in second delay
prompt or until you break out for SQL &sql_id_in : &fphv_in ...

declare
  samples_v                  integer;
  total_execs_v              integer;
  time_micro_v        integer;
  total_execs_prior_v        integer;
  time_micro_prior_v  integer;
  total_execs_delta_v        integer;
  time_micro_delta_v  integer;
  avg_exec_time_ms_v         integer;

begin
  select sum(executions), sum(elapsed_time)
  into   total_execs_prior_v, time_micro_prior_v
  from   v$sql
  where  sql_id = '&sql_id_in'
    and  ( full_plan_hash_value = &fphv_in
           OR
           plan_hash_value = &fphv_in
         );

  samples_v := 1;

  while ( samples_v <= &samples_in )
  loop
  
    select sum(executions), sum(elapsed_time)
    into   total_execs_v, time_micro_v
    from   v$sql
    where  sql_id = '&sql_id_in'
      and  ( full_plan_hash_value = &fphv_in
           OR
           plan_hash_value = &fphv_in
           );

    if ( total_execs_v > total_execs_prior_v ) then
      total_execs_delta_v       := total_execs_v - total_execs_prior_v ;
      time_micro_delta_v        := time_micro_v - time_micro_prior_v ;
      avg_exec_time_ms_v        := ( time_micro_delta_v / total_execs_delta_v ) / 1000 ;

      insert into op_elapsed_samples values ( total_execs_delta_v, avg_exec_time_ms_v );

      total_execs_prior_v  := total_execs_v ;
      time_micro_prior_v   := time_micro_v ;

      samples_v            := samples_v +1;
    end if;

    dbms_lock.sleep(&delay_in);

  end loop;
  commit;
end;
/

prompt
prompt Your event time samples have been stored in the op_elapsed_samples table.
prompt

start osmclear

