------------------------------------------------------------
-- file         sqlelget11.sql
-- desc         Get SQL elapsed time for a given SQL_ID and Plan Hash Value
-- author       Craig A. Shallahamer, craig@orapub.com
-- orig         01-may-2014
-- lst upt      14-jul-2015 
-- copyright    (c)2014,2015 OraPub, Inc.
-- usage        @sqlelget11.sql SQL_ID FULL_PLAN_HASH_VALUE SAMPLES_TO_GET MAX_LOOPS
--				@sqlelget11.sql 935zbvd783kxc 3885585458  5 10000
-- Get high execution sql : select sql_id, plan_hash_value, executions, elapsed_time from v$sql order by 3,1,2
------------------------------------------------------------

-- All output is formatted so you can copy/paste directly into an
-- the R Statistics ( r-project.org ) package.

-- This script does ZERO DDL and ZERO DML and does not use DBMS_Lock.sleep
-- This means you can simply copy and paste the code into SQL*Plus.

-- You really want over a samples, not 3, 11 or even 30 samples.

-- You have three execution strategies:
--
-- 1. Standard with parameters given on command line
--    @sqlelget11.sql sql_ID        plan_hash_value  max samples  max loops
--    @sqlelget11.sql 935zbvd783kxc 3885585458       5            500000

-- 2. Copy and paste
--    Copy everything between the obvious COPY/PASTE comments below
--    Paste into sqlplus

-- 3. Have sqlplus prompt you for the input defines
--    @sqlelget11 


undef EnterSqlId
undef EnterPlanHashValue
undef EnterSampleCount
undef EnterMaxLoops

prompt Parameter 1 is the SQL_ID (e.g., 935zbvd783kxc)
def EnterSqlId=&1
prompt Parameter 2 is the PLAN_HASH_VALUE (e.g., 3885585458)
def EnterPlanHashValue=&2
prompt Parameter 3 is the number of elapsed time SAMPLES (e.g., 30)
def EnterSampleCount=&3
prompt Parameter 4 is the maximum number of LOOPS (e.g., 1000)
def EnterMaxLoops=&4

-- To Copy/Paste, ensure the below three defines are set

def SqlId=&EnterSqlId
def PlanHashValue=&EnterPlanHashValue
def SampleCount=&EnterSampleCount
def MaxLoops=&EnterMaxLoops

------------------------------------------------------
-- COPY/PASTE START HERE (make sure the three defines above are set)

set tab off
set verify off
set linesize 300
set trimspool on
set serveroutput on


def EnterSqlId
def EnterPlanHashValue
def EnterSampleCount
def EnterMaxLoops

prompt .
prompt Starting to collect &SampleCount samples up to &MaxLoops loops
prompt for SQL &SqlId : &PlanHashValue
prompt The resulting elapsed times are in milliseconds.
prompt ...

declare
	loop_cntr_v				integer;
	actual_loops_v			integer;
	samples_v				integer;
	total_execs_v			integer;
	time_micro_v			integer;
	total_execs_prior_v		integer;
	time_micro_prior_v 		integer;
	total_execs_delta_v		integer;
	time_micro_delta_v		integer;
	avg_exec_time_ms_v		integer;

begin
	select sum(executions), sum(elapsed_time)
	into   total_execs_prior_v, time_micro_prior_v
	from   v$sql
	where  sql_id = '&SqlId'
	  and  plan_hash_value = &PlanHashValue ;

	samples_v := 1;

	BEGIN
	
	for loop_cntr_v in 1..&MaxLoops
	loop
		select sum(executions), sum(elapsed_time)
		into   total_execs_v, time_micro_v
		from   v$sql
		where  sql_id = '&SqlId'
		  and  plan_hash_value = &PlanHashValue ;

		if ( total_execs_v > total_execs_prior_v ) then
			total_execs_delta_v       := total_execs_v - total_execs_prior_v ;
			time_micro_delta_v        := time_micro_v - time_micro_prior_v ;
			avg_exec_time_ms_v        := ( time_micro_delta_v / total_execs_delta_v ) / 1000 ;

			dbms_output.put_line(round(avg_exec_time_ms_v,6)||',');
			
			--sql_times_avar(samples_v) := avg_exec_time_ms_v
			--insert into op_elapsed_samples values ( total_execs_delta_v, avg_exec_time_ms_v );

			total_execs_prior_v  := total_execs_v ;
			time_micro_prior_v   := time_micro_v ;

			samples_v            := samples_v +1;
		end if;
		
		actual_loops_v := loop_cntr_v ;
		
		EXIT WHEN ( samples_v > &SampleCount ) ;
	end loop;
	
	END;

    dbms_output.put_line('Samples collected = '||(samples_v-1)||' during '||actual_loops_v||' loops');

end;
/

prompt
prompt To create an R sample set, place the above sample values into R like this:
prompt ss<-c( samples go here )
prompt Be sure to remove the final comma.


