-- ********************************************************************
-- * Filename		: sqlgettext.sql
-- * Author		: Craig A. Shallahamer
-- * Original		: 05-Dec-2014
-- * Last Update	: 17-Jan-2017
-- * Copyright          : (c)2014,2017 OraPub, Inc.
-- * Description	: Show SQL statement text for a given identifier
-- * Usage		: start sqlgettext.sql <v$sql id column> <id value>
-- ********************************************************************

def id_key=&1
def id_value=&2

def osm_prog    = 'sqlgettext.sql'
def osm_title   = 'Get SQL Statement Text (&id_key like &id_value)'
def osm_title2  = ''

col text	heading 'SQL Statement Text'    format          a100

start osmtitlem

set linesize 115

select 	sql_id, 
	sql_text text 
from 	v$sql 
where 	lower(&id_key) like '&id_value' 
  and 	sql_text not like '%v$sql%'
/

start osmclear

