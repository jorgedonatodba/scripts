-- ********************************************************************
-- * Copyright Notice   : (c)1998-2007,2008 OraPub, Inc.
-- * Filename			: sqls1.sql 
-- * Author				: Craig A. Shallahamer
-- * Original			: 17-AUG-98
-- * Last Update		: 01-Sep-2015
-- * Description		: Identify top SQL statements.
-- * Usage		: start sqls1.sql <min disk rds> <min buff rds>
-- * Thanks		  1) Thanks to Geert van Lierop for tip to use
-- *			     "address" instead of "hash_value".
-- *			  2) Thanks to Ghassan Salem for taking the time
-- *			     to create the core wait based loading code.
-- ********************************************************************

def min_pio=&&1
def min_lio=&&2

prompt For proper sort and output, swpctx.sql must have been run.
prompt

def osm_prog    = 'sqls1.sql'
def osm_title   = 'Intelligent Top SQL Statement Activity Summary'
def osm_title2  = ''

col mod         heading 'Stmt Addr'             format          a16
col dr          heading 'Phys Rds|(k)'              format  999,999
col bg          heading 'Log Rds|(k)'               format  999,999
col cpu         heading 'CPU Time|(min)'        format      999,990.0
col sr          heading 'Sorts'                 format        9,999
col exe         heading 'Runs'                  format      999,999
col rows_p      heading 'Rows|(k)'              format       99,990
col load        heading 'Load Factor'           format      999,999 noprint
col pio_time    heading 'Sec/PIO'               format           90.000
col lio_time    heading 'Sec/LIO'               format           90.000
col exe_time    heading 'Sec/EXE'               format        9,990.00
col etime       heading 'Tot Time|(min)'        format       99,990.0
col stype       heading 'Stmt|Type'             format           a5
col appwt		heading 'APPL WT'				format		999,990
col curwt		heading 'Concur WT'				format		999,990
col clswt		heading 'Cluster WT'			format	    999,990
col uiowt		heading 'User IO WT'			format      999,990
col plswt		heading 'PL/SQL WT'				format	    999,990
col javwt		heading 'Java WT'			    format      999,990
col sql_id		heading 'SQL ID'	

start osmtitlell

select
  a.sql_id,
  a.address                       mod,
  (a.elapsed_time/1000000)/(a.executions+0.0000001)	  exe_time,
  a.disk_reads/1000                    dr,
  a.buffer_gets/1000                   bg,
  a.elapsed_time/1000000/60	  etime,
  a.cpu_time/1000000/60           cpu,
  (a.elapsed_time/1000000)/(a.disk_reads+0.00000001)	  pio_time,
  (a.elapsed_time/1000000)/(a.buffer_gets+0.00000001)	  lio_time,
  a.executions                    exe,
  a.rows_processed/1000		  ROWS_p,
  a.sorts		  sr,
  APPLICATION_WAIT_TIME/1000 appwt,
  CONCURRENCY_WAIT_TIME/1000 curwt,
  CLUSTER_WAIT_TIME/10000 clswt,
  USER_IO_WAIT_TIME/10000 uiowt,
  PLSQL_EXEC_TIME/10000 plswt,
  JAVA_EXEC_TIME/10000 javwt,  
  substr(a.sql_text,1,5) 		  stype,
  a.disk_reads*1000+a.buffer_gets load
from
  v$sql a
 where	disk_reads > &min_pio
   and	buffer_gets > &min_lio
 order by
  load desc
/

undef min_blocks

start osmclear
