-- ********************************************************************
-- * Copyright Notice   : (c)2017 OraPub, Inc.
-- * Filename		: sqlsimchar.sql 
-- * Author		: Craig A. Shallahamer
-- * Original		: 18-Jan-2017
-- * Last Update	: 
-- * Description	: Identify similar SQL_IDs based on first n chars
-- *                      of text.
-- * Usage		: start sqlsimchar.sql <chars to consider> <formating: l,r,a>
-- ********************************************************************

def chars=&&1
def fmt=&&2

def osm_prog    = 'sqlsimchar.sql'
def osm_title   = 'Identify Similar SQL Statements (first &chars characters, format: &fmt)'

col stmt        heading 'SQL Statement' format          a&chars
col the_count   heading 'Count'         format      999,990

start osmtitle

col x noprint

select
  sql_id sqlid,
  substr(sql_text,1,&chars)       stmt,
  count(*)			  the_count
from
  v$sql
group by sql_id, substr(sql_text,1,&chars)
having count(*) > 1
order by 2 
/

undef chars

start osmclear


