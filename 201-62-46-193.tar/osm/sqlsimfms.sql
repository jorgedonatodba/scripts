-- ********************************************************************
-- * Filename		: sqlsimfms.sql
-- * Author		: Craig A. Shallahamer
-- * Original		: 18-Jan-2017
-- * Last Update	: 18-Jan-2017
-- * Copyright          : (c)2017 OraPub, Inc.
-- * Description	: List FMS for similar SQL statements
-- * Usage		: start sqlsimfms.sql <min sql_id count> <min exec count> <some sql text>
-- * Example		: start sqlsimfms 2 2 dual
-- ********************************************************************

def minSqlCount=&1
def minExecCount=&2
def yourSQL=&3

def osm_prog    = 'sqlsimfms.sql'
def osm_title   = 'List Force Matching Signatures For Similar SQL Statements'
def osm_title2  = '(min counts: sql_id>&minSqlCount, execs>&minExecCount. sql_text like &yourSQL)'

set linesize 300
col fms 	format 99999999999999999999 heading 'Force Matching Signature'
col sqlcnt	format      999,999,999,999 heading 'Distinct SQL_IDs'
col execnt	format      999,999,999,999 heading 'Total Executions'

start osmtitles

--set linesize 115

select	force_matching_signature fms, 
	count(distinct(sql_id)) sqlcnt, 
	sum(executions) execnt
from   	v$sql
where  	lower(sql_text) like '%&yourSQL%'
  and  	lower(sql_text) not like '%v$sql%'
group by force_matching_signature
having count(distinct(sql_id)) > &minSqlCount
   and sum(executions) > &minExecCount
/

start osmclear

