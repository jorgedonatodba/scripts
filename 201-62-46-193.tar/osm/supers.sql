-- ********************************************************************
-- * Copyright Notice   : (c)2007 OraPub, Inc.
-- * Filename		: supers.sql - Super-serial scalability data gather
-- * Author		: Craig A. Shallahamer
-- * Original		: 11-dec-06
-- * Last Update	: 11-dec-06
-- * Description	: Gather super-serial scalability data
-- * Usage		: start supers.sql
-- ********************************************************************

select to_char(sysdate,'DD-Mon-YYYY HH24:MI:SS') sample,
       we.concur_waits,
       ss.executes
from   (
         select sum(total_waits) concur_waits
         from   v$system_event
         where  event_id in (
                  select b.event_id
                  from   v$event_name b
                  where  wait_class#=4
                )
       ) we,
       (
         select value executes
         from   v$sysstat
         where  name = 'execute count'
       ) ss
/


