-- ********************************************************************
-- * Copyright Notice  : (c)2015 OraPub, Inc. - Use this software at your own risk!  There are no implied warrenties or guarentees.
-- * Filename          : swEhAwrGet.sql - Get v$event_histogram wait data from AWR
-- *                     and generate R code for script, swEhCharts.r
-- * Author            : Craig Shallahamer, craig@orapub.com
-- * Original          : 27-Apr-2015
-- * Last Update       : 14-May-2015
-- * Description       : Get DBA_HIST_EVENT_HISTOGRAM data for a specific event and
-- *                     generate the R statistical input code for input into
-- *					 R script, swEhCharts.r
-- * Usage             : start swEhAwrGet.sql
-- ********************************************************************

set tab off
set verify off
set linesize 300
set trimspool on
set serveroutput on

select dbid, instance_number, 
        min(snap_id) First_Snap_Id, 
        to_char(min(begin_interval_time),'DD-Mon-YYYY HH24:MI:SS') begin_interval_time,
        max(snap_id) Last_Snap_Id, 
        to_char(max(begin_interval_time),'DD-Mon-YYYY HH24:MI:SS') begin_interval_time
from	dba_hist_snapshot
group by dbid, instance_number
order by 1,2,3
/

prompt
accept dbid 	prompt 	"ENTER the database ID (DBID)                                : "
accept instnum	prompt	"ENTER the instance number                                   : "
accept DTmin	prompt	"ENTER the approximate starting date/hour (DD-Mon-YYYY HH24) : "
accept DTmax	prompt	"ENTER the approximate ending   date/hour (DD-Mon-YYYY HH24) : "

select	snap_id,
		to_char(begin_interval_time,'DD-Mon-YYYY HH24:MI:SS'),
		to_char(end_interval_time,'DD-Mon-YYYY HH24:MI:SS')		
from	dba_hist_snapshot snap
where	dbid            = &dbid
  and	instance_number = &instnum
  and	begin_interval_time >= to_date('&DTmin','DD-Mon-YYYY HH24') - INTERVAL '1' HOUR
  and	end_interval_time   <= to_date('&DTmax','DD-Mon-YYYY HH24') + INTERVAL '1' HOUR
order by 1
/

accept snap_start prompt "ENTER the beginning snap_id                 : "
accept snap_end   prompt "ENTER the ending    snap_id                 : "
accept ename	  prompt "ENTER the wait event (default: db%seq%read) : " default "db%seq%read"

prompt Copy and paste the below R code directly into the swEhCharts.r
prompt It must be the last entry in the #2 area of swEhCharts.r
prompt 
prompt ### START ###

set heading off
select 'eName = "&eName"' from dual;
set heading on

declare
  power2_var		number;
  i_var				number;
  output_var		varchar2(500);
  count_diff_var	number;
  min_ms_wait_var	number;
  max_ms_wait_var	number;
begin

	for power2_var in 0..18
	loop
		max_ms_wait_var := power(2,power2_var);
		
		select	nvl(max(wait_count)-min(wait_count),0)
		into	count_diff_var
		from	dba_hist_event_histogram hist
		where	dbid            = &dbid
		  and	instance_number = &instnum
		  and	snap_id between &snap_start and &snap_end
		  and	wait_time_milli = max_ms_wait_var
		  and	event_name like '&ename%'
		;

		if ( power2_var = 0 ) then
			min_ms_wait_var := 0;
		else
			min_ms_wait_var := power(2,power2_var-1);
		end if;
		
		--output_var := 'power2_var=' || power2_var || ' min_ms_wait_var=' || min_ms_wait_var || ' max_ms_wait_var=' || max_ms_wait_var || ' count_diff_var=' || count_diff_var ;
		--dbms_output.put_line(output_var);
		
		output_var := 'count' || min_ms_wait_var || 'to' || max_ms_wait_var || ' = ' || count_diff_var ;
		dbms_output.put_line(output_var);

	end loop;
end;
/

prompt 
prompt ### END : Do NOT COPY and PASTE the "PL/SQL procedure..." TEXT INTO R ###
prompt








  
