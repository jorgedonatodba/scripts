-- ********************************************************************
-- * Copyright Notice  : (c)2015 OraPub, Inc.
-- * Filename          : swEhVdGet.sql - Get v$event_histogram wait 
-- *                     times and generate R code for visual hist analysis
-- * Author            : Craig Shallahamer, craig@orapub.com
-- * Original          : 27-Apr-2015
-- * Last Update       : 28-Apr-2015
-- * Description       : Get v$event_histogram data for a specific event to paste
-- *                     OSM tool swEhCharts.r to create stats and histograms.
-- * Usage             : start swHistGenV.sql
-- *                     @swEhVdGet
-- *                     @swEhVdGet 1000 30 db%file%seq%read
-- ********************************************************************

-- All output is formatted so you can copy/paste directly into an
-- OSM script, swEhCharts.r which will create the R Statistics ( r-project.org )
-- code that can be then copy and pasted directly into R creating
-- a number of useful statistics and histograms.

-- This script does ZERO DDL and ZERO DML and does not use DBMS_Lock.sleep
-- This means you can simply copy and paste the code into SQL*Plus.

-- You really want thousands of samples, not 30 or 100 or 500 samples.
-- Otherwise, you may not capture the infrequent large wait occurances.

-- You have three execution strategies:
--
-- 1. Standard with parameters given on command line
--    @swEhVdGet  max_sample_loops  min_samples_required  wait_event_name
--    @swEhVdGet 2000 20 log%file%switch%check%inc%  -- test
--	  @swEhVdGet 1000 12000 db%file%seq%read
--	  @swEhVdGet 1000 50000 db%file%seq%read
--    @swEhVdGet 1000 30 db%file%seq%read  -- test
--    @swEhVdGet 1000 10000 db%file%seq%read  - real system
--	  @swEhVdGet 500 20 enq%TX%row%

-- 2. Copy and paste
--    Copy everything between the obvious COPY/PASTE comments below
--    Paste into sqlplus

-- 3. Have sqlplus prompt you for the input defines
--    @swEhVdGet 


set tab off
set verify off
set linesize 300
set trimspool on
set serveroutput on

undef MaxSampleLoops
undef EnterMaxSampleLoops
undef MinSampleCount
undef EnterMinSampleCount
undef eName
undef EnterEventName

prompt Parameter 1 is the Maximum Number Of Sampling Loops (e.g., 100)
def EnterMaxSampleLoops=&1
prompt Parameter 2 is the Minimum Number of Samples To Collect (e.g., 200)
def EnterMinSampleCount=&2
prompt Parameter 3 is the Wait Event Name (e.g., db%file%seq%read)
def EnterEventName='&3'


-- To Copy/Paste, ensure the below three defines are set

def maxSampleLoops=&EnterMaxSampleLoops
def minSampleCount=&EnterMinSampleCount
def eName=&EnterEventName

------------------------------------------------------
-- COPY/PASTE START HERE (make sure the three defines above are set)

set tab off
set verify off
set linesize 300
set trimspool on
set serveroutput on

def maxSampleLoops
def minSampleCount
def eName

prompt
prompt Collecting event wait times...
prompt

prompt Copy and paste the below R code directly into the swEhCharts.r
prompt It must be the last entry in the #2 area of swEhCharts.r
prompt 
prompt ### START ###

set heading off
select 'eName = "&eName"' from dual;
set heading on

DECLARE
	output_var			varchar2(500);
	type ev_times_array is varray(9999) of integer;
	
	ev_times_start_avar	ev_times_array := ev_times_array();
	ev_times_end_avar	ev_times_array := ev_times_array();
	ev_times_diff_avar	ev_times_array := ev_times_array();
	
	small_var			number := 0.00000000000010;
	some_output_var		varchar2(1);
	random_seed_var		number := 13 ;
	final_samples_all_var varchar2(5000);
	
	power2_var				number;
	min_ms_wait_var			number;
	max_ms_wait_var			number;
	min_ms_bin_var			number;
	max_ms_bin_var			number;
	max2power_var			number := 1+18;
	i_var					number;
	looper_var				number;
	max_r_samples_var		number := 1000;
	r_bin_count_var			number;
	total_wait_counts_var	number;
	bin_sample_var			number;
	sample_waits_start_var	number;
	sample_waits_end_var	number;
	sample_wait_diff_var	number;
	actual_sample_loops_var	number;
	
BEGIN
	--
	-- initalize the arrays
	--
	for looper_var in 1..max2power_var
	loop
		ev_times_start_avar.extend;
		ev_times_start_avar(looper_var) := 0 ;
		ev_times_end_avar.extend;
		ev_times_end_avar(looper_var) := 0 ;
		ev_times_diff_avar.extend;
		ev_times_diff_avar(looper_var) := 0 ;
	end loop;
	
	--
	-- Get initial v$event_histogram samples
	--
	for power2_var in 0..max2power_var-1
	loop
		max_ms_wait_var := power(2,power2_var);
  
  		BEGIN
			select	wait_count
			into	ev_times_start_avar(power2_var+1)
			from	v$event_histogram
			where	event like '&eName%'
			  and	WAIT_TIME_MILLI = max_ms_wait_var
			;  
			EXCEPTION WHEN OTHERS THEN ev_times_start_avar(power2_var+1) := 0;
		END;
		
		--output_var := 'SRT  power2_var='||power2_var||' max_ms_wait_var='||max_ms_wait_var||' ev_times_start_avar(power2_var+1)='||ev_times_start_avar(power2_var+1) ;
		--dbms_output.put_line(output_var);

	end loop;

	-- ** The SLEEP Strategy **
	-- 
	-- Spin up to minSampleLoops BUT exit if minSampleCount samples have been collected.
	-- 
	-- This sleep strategy will likely consume an entire CPU core. So make sure
	-- you have one free core of CPU available!!!!!!!
	--
	-- Note: If you have less than around 30 samples, the histogram will look bad.

	select	total_waits
	into	sample_waits_start_var
	from	v$system_event
	where	event like '&eName'
	;
	
	actual_sample_loops_var := 0;
	
	BEGIN
		for i_var in 1..&maxSampleLoops
		loop
			select	total_waits
			into	sample_waits_end_var
			from	v$system_event
			where	event like '&eName'
			;   			
			sample_wait_diff_var := sample_waits_end_var - sample_waits_start_var ;
			actual_sample_loops_var := i_var ;
			--dbms_output.put_line('#  Sample loop ' || i_var || ' with ' || sample_wait_diff_var || ' samples collected so far.');
			EXIT WHEN ( sample_wait_diff_var > &minSampleCount ) ;
		end loop;	
	END;


	dbms_output.put_line('### There were ' || actual_sample_loops_var || ' sampling loops completed and ' || sample_wait_diff_var || ' samples collected.');
	dbms_output.put_line('###');
	--
	-- Get ending samples from v$event_histogram
	--
	for power2_var in 0..max2power_var-1
	loop
		max_ms_wait_var := power(2,power2_var);
  
  		BEGIN
			select	wait_count
			into	ev_times_end_avar(power2_var+1)
			from	v$event_histogram
			where	event like '&eName'
			  and	WAIT_TIME_MILLI = max_ms_wait_var
			;  
			EXCEPTION WHEN OTHERS THEN ev_times_end_avar(power2_var+1) := 0;
		END;
		
		--output_var := 'END  power2_var='||power2_var||' max_ms_wait_var='||max_ms_wait_var||' ev_times_end_avar(power2_var+1)='||ev_times_end_avar(power2_var+1) ;
		--dbms_output.put_line(output_var);

	end loop;
	
	--
	-- Calc the difference and create output
	--

	for power2_var in 0..18
	loop
		max_ms_wait_var := power(2,power2_var);
		
		ev_times_diff_avar(power2_var+1) := ev_times_end_avar(power2_var+1) - ev_times_start_avar(power2_var+1) ;

		if ( power2_var = 0 ) then
			min_ms_wait_var := 0;
		else
			min_ms_wait_var := power(2,power2_var-1);
		end if;
		
		--output_var := 'power2_var=' || power2_var || ' min_ms_wait_var=' || min_ms_wait_var || ' max_ms_wait_var=' || max_ms_wait_var || ' difference is ' || count_diff_var ;
		--dbms_output.put_line(output_var);
		
		output_var := 'count' || min_ms_wait_var || 'to' || max_ms_wait_var || ' = ' || ev_times_diff_avar(power2_var+1) ;
		dbms_output.put_line(output_var);

	end loop;	
end;
/
	
	
prompt 
prompt ### END : Do NOT COPY and PASTE the "PL/SQL procedure..." TEXT INTO R ###
prompt

------------------------------------------------------
-- COPY/PASTE ENDS HERE (make sure the three defines above are set)



