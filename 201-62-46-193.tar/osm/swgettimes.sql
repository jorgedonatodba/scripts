------------------------------------------------------------
-- file         swgettimes.sql
-- desc         Get wait time samples by event name
-- author       Craig A. Shallahamer, craig@orapub.com
-- orig         01-may-2014
-- lst upt      07-may-2014 
-- copyright    (c)2014 OraPub, Inc.
-- usage        swgettimes.sql free%buffer%wait% 100 0.10
-- notes		You may be interested in the v$event_histogram related
--              scripts that create input to he R statistical program
--              creating histograms. Look for the OSM scripts starting
--              with "swEv"...
------------------------------------------------------------

def ename=&1
def samples=&2
def delay=&3

set echo off
set feedback off
set heading off
set verify off

prompt
prompt &samples will be gathered or until you break out...
prompt
prompt Dropping/creating the op_wait_samples table...
drop   table op_wait_samples;
create table op_wait_samples ( samples number, sample_time_ms number );

prompt Starting to collect samples...

declare
  samples_v                  integer;
  total_waits_v              integer;
  time_waited_micro_v        integer;
  total_waits_prior_v        integer;
  time_waited_micro_prior_v  integer;
  total_waits_delta_v        integer;
  time_waited_micro_delta_v  integer;
  avg_wait_time_ms_v         integer;

begin
  select total_waits,         time_waited_micro
  into   total_waits_prior_v, time_waited_micro_prior_v
  from   v$system_event
  where  event like '&ename';

  samples_v := 1;

  while ( samples_v <= &samples )
  loop

    select total_waits, time_waited_micro
    into   total_waits_v, time_waited_micro_v
    from   v$system_event
    where  event like '&ename';

    if ( total_waits_v > total_waits_prior_v ) then
      total_waits_delta_v       := total_waits_v - total_waits_prior_v ;
      time_waited_micro_delta_v := time_waited_micro_v - time_waited_micro_prior_v ;
      avg_wait_time_ms_v        := ( time_waited_micro_delta_v / total_waits_delta_v ) / 1000 ;

      insert into op_wait_samples values ( total_waits_delta_v, avg_wait_time_ms_v );

      total_waits_prior_v       := total_waits_v ;
      time_waited_micro_prior_v := time_waited_micro_v ;

      samples_v                 := samples_v +1;
    end if;

    dbms_lock.sleep(&delay);

  end loop;
  commit;
end;
/

prompt
prompt Your event time samples have been stored in the op_wait_samples table.
prompt

start osmclear

