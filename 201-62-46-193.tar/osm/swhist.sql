------------------------------------------------------------
-- file		swhist.sql
-- desc		Session wait statitics histogram (<event name>)
-- author	Craig A. Shallahamer, craig@orapub.com
-- orig		03-April-07
-- lst upt	21-Dec-11 
-- copyright	(c)2007,2011 OraPub, Inc.
------------------------------------------------------------

def ev_name=&1

set echo off
set feedback off
set heading off
set verify off

col val2 new_val total_waits noprint

select	sum(wait_count) val2
from	v$event_histogram
where	event like '%&ev_name%'
/
		      
set echo off
set feedback off
set heading on
set verify off

def osm_prog	= 'swhist.sql'
def osm_title	= 'Wait Event Activity Histogram (event:&ev_name)'

start osmtitle

col event		format a35			heading "Wait Event" trunc
col wtm			format 99999		heading "ms Wait <="
col wait_count	format 9999999990	heading "Occurs"
col pct_occurs  format  990.00 heading "Pct|Occurs"
col pct_rt		format 990.00		heading "Running|Occurs %"

select	event,
	wait_time_milli wtm,
	wait_count,
	100*wait_count/&total_waits pct_occurs,
	100*(sum(wait_count) over (order by event,wait_time_milli))/&total_waits pct_rt
from	v$event_histogram
where	event like '%&ev_name%'
order by 1,2
/

start osmclear

