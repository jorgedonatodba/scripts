------------------------------------------------------------
-- file		swhistx.sql
-- desc		Session wait DELTA statitics histogram (<event name>)
-- author	Craig A. Shallahamer, craig@orapub.com
-- orig		03-April-07
-- lst upt	21-Dec-2011
-- copyright	(c)2007,2011 OraPub, Inc.
------------------------------------------------------------

def ev_name=&1

prompt Remember: This report must be run twice so both
prompt the initial and final values are available.

set echo off
set feedback off
set heading off
set verify off
set termout off

def start_time=&end_time noprint

col val2 new_val delta_count noprint

col val1 new_value end_time noprint
select  to_char(sysdate,'DD-Mon-YYYY:HH24:MI:SS') val1
from    dual
/

col v2 new_value interval_s noprint
select  ltrim(round((to_date('&end_time','DD-Mon-YYYY:HH24:MI:SS')-to_date('&start_time','DD-Mon-YYYY:HH24:MI:SS'))*24*60*60,1)) v2 
from    dual
/

select	sum(t1.wait_count-t0.wait_count) val2
from	v$event_histogram t1,
	event_histogram_snap t0
where	t1.event like '%&ev_name%'
  and	t1.event = t0.event
  and	t1.wait_time_milli = t0.wait_time_milli
/

set echo off
set feedback off
set heading on
set verify off
set termout on

def osm_prog	= 'swhistx.sql'
def osm_title	= 'Wait Event Activity Delta Histogram (&interval_s sec interval, event:&ev_name)'

start osmtitle

col event		format a35			heading "Wait Event" trunc
col wtm			format 99999		heading "ms Wait <="
col delta_count	format 9999999990	heading "Delta Occurs"
col pct_occurs		format 990.00		heading "Occurs %"
col pct_rt		format 990.00		heading "Running|Occurs %"

select	t1.event,
		t1.wait_time_milli wtm,
		t1.wait_count-t0.wait_count delta_count,
		100*(t1.wait_count-t0.wait_count)/&delta_count pct_occurs,
		100*(sum(t1.wait_count-t0.wait_count)
			over (order by t1.event,t1.wait_time_milli))/&delta_count pct_rt
from	v$event_histogram t1,
	event_histogram_snap t0
where	t1.event like '%&ev_name%'
  and	t1.event = t0.event
  and	t1.wait_time_milli = t0.wait_time_milli
order by 1,2
/

truncate table event_histogram_snap
/
insert /*+ APPEND */ into event_histogram_snap nologging
select * 
from   v$event_histogram b
where  b.event not in ( select a.event
			from   o$event_type a
			where  a.type in ('bogus','idle')
		       )
/
commit;

start osmclear

