-- ********************************************************************
-- * Copyright Notice   : (c)2013 OraPub, Inc.
-- * Filename		: swname.sql - Version 1.0
-- * Author		: Craig A. Shallahamer
-- * Original		: 13-SEP-2013
-- * Last Update	: 13-SEP-2013
-- * Description	: Show Session Wait name and display name
-- * Usage		: start swname.sql <partial name>
-- ********************************************************************

def input=&1

def osm_prog="swname.sql"
def osm_title="Session Wait Name and Display Name"
start osmtitles

col name    format     a35  heading "Event Name Event" wrap
col display  format    a35  heading "Event Display Name" wrap
col eid      format    99999999990 heading "Event ID"
col wc       format    a10  heading "Wait Class" trunc
select name,
       display_name display,
       wait_class wc,
       event_id eid
from   v$event_name
where  lower(name) like '%&input%'
   or  lower(display_name) like '%&input%'
order by 1
/

start osmclear

