------------------------------------------------------------
-- file		swpctidle.sql
-- desc		Session wait statitics percentage reporting. Only IDLE events
-- author	Craig A. Shallahamer, craig@orapub.com
-- orig		16-March-09
-- lst upt	16-March-09 
-- copyright	(c)2009 OraPub, Inc.
------------------------------------------------------------

def filter=&1

set echo off
set feedback off
set heading off
set verify off

col val1 new_val tot_time_waited noprint
col val2 new_val tot_total_waits noprint

select		sum(time_waited) val1,
		sum(total_waits) val2
from		v$system_event a
where a.event in (	select event
			from   o$event_type
			where  type in ('bogus','idle')
		      )

set echo off
set feedback off
set heading on
set verify off

def osm_prog	= 'swpct.sql'
def osm_title	= 'Idle/Bogus System Event Activity By PERCENT'

start osmtitle

col event	format a35	heading "Idle Wait Event" trunc
col tw	 	format 99999990	heading "Time Waited|(min)"
col time_pct 	format 990.00	heading "% Time|Waited"
col avg_time 	format 99990.0	heading "Avg Time|Waited (ms)"
col wc	 	format 99990	heading "Waits|Count (m)"

select 	event,
	(time_waited/100)/60 tw,
	100*(time_waited/a.tot_time_waited) time_pct,
	1000*((time_waited/100)/total_waits) avg_time,
	total_waits/1000 wc
from   v$system_event,
	(
	  select	sum(time_waited) tot_time_waited,
			sum(total_waits) tot_total_waits
	  from		v$system_event a
	  where a.event in ( select event
				 from   o$event_type
				 where  type in ('bogus','idle')
		               )
	) a
where  event like '&filter%'
  and  event in (	select event
			from   o$event_type
			where  type in ('bogus','idle')
	        )
  and  time_waited > 1000
order by time_pct desc
/

start osmclear

