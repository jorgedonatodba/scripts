-- ********************************************************************
-- * Copyright Notice   : (c)1998 OraPub, Inc.
-- * Filename		: swswp.sql - Version 1.0
-- * Author		: Craig A. Shallahamer
-- * Original		: 25-SEP-98
-- * Last Update	: 28-OCT-09
-- * Description	: Show Session Wait Realtime w/Parameters
-- * Usage		: start swswp.sql
-- ********************************************************************

def input=&1

def osm_prog="swswp.sql"
def osm_title="Session Wait Real Time w/Parameters"
start osmtitles

col sid	   format    9999  heading "Sess|ID"
col event  format     a28  heading "Wait Event" wrap
col siw    format    9990.000  heading "Waited|So Far|(sec)"
col p1     format    99999999999  heading "P1"
col p2     format     99999999  heading "P2"
col p3     format         9999  heading "P3"

select sid, event,
       p1, p2, p3
from   v$session_wait
where  event like '&input%'
  and  state = 'WAITING'
order by event,sid,p1,p2;

start osmclear

