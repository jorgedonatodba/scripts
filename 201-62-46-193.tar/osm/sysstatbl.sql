------------------------------------------------------------
-- file		sysstatbl.sql
-- desc		Get v$sysstat+ baseline details for a lots of stats
-- author	Craig A. Shallahamer, craig@orapub.com
-- orig		17-July-2015
-- lst upt	12-Jan-2017 
-- copyright (c)2015,2017 OraPub, Inc.
--
-- @osmsetvar must be run to init variables


set tab off
set echo off
set feedback off
set heading on
set verify off
set termout on
set serveroutput on

@sysstatblRaw 1 'db block changes'
@sysstatblRaw 2 'session logical reads' 
@sysstatblRaw 3 'physical read total IO requests'
@sysstatblRaw 4 'user commits'
@sysstatblRaw 5 'parse time cpu'
@sysstatblRaw 6 'CPU used by this session'
@sysstatblRaw 7 'parse count (hard)'
@sysstatblRaw 8 'parse count (total)'
