------------------------------------------------------------
-- file		sysstatblRaw.sql
-- desc		Get v$sysstat baseline details for a single stat
-- author	Craig A. Shallahamer, craig@orapub.com
-- orig		17-July-2015
-- lst upt	17-July-2015 
-- copyright	(c)2015 OraPub, Inc.
--
-- @osmvarset must have been run to init variables
-- usage	@sysstatblRaw 1..5  stat_name
-- 		    @sysstatblRaw 1     'db block changes'
-- 		    @sysstatblRaw 2     'user calls'
-- 		    @sysstatblRaw 3     'session logical reads'
-- note		NO ddl, dml or dbms_lock usage
------------------------------------------------------------ 

def sysstatblv=&1
def sysstatblStatName='&2'

set tab off
set echo off
set feedback off
set heading on
set verify off
set termout on


set serveroutput on
declare
	rate_v		number;
begin
	select value-:sysstatbl_v&sysstatblv
	into   :sysstatbl_v&sysstatblv
	from   v$sysstat
	where  name='&sysstatblStatName';
	
	select (to_number(to_char(sysdate,'SSSSS'))-:sysstatbl_sssss_v&sysstatblv)
	into   :sysstatbl_sssss_v&sysstatblv
	from   dual;

	rate_v := :sysstatbl_v&sysstatblv / :sysstatbl_sssss_v&sysstatblv ;
	
	dbms_output.put_line(rpad('&sysstatblStatName',35)||'  '||lpad(:sysstatbl_v&sysstatblv,10)||'  '||lpad(round(rate_v,1),10) ||
		lpad(:sysstatbl_sssss_v&sysstatblv,5)||'  ');
	
	select value
	into   :sysstatbl_v&sysstatblv
	from   v$sysstat
	where  name='&sysstatblStatName';

	select to_number(to_char(sysdate,'SSSSS'))
	into   :sysstatbl_sssss_v&sysstatblv
	from   dual;
end;
/

start osmclear

