-- ********************************************************************
-- * Copyright Notice   : (c)2002 OraPub, Inc.
-- * Filename		: tbfsum.sql - Table Block Frag Summary
-- * Author		: Craig A. Shallahamer
-- * Original		: 20-Nov-2002
-- * Last Update	: 20-Nov-2002
-- * Description	: Quickly show table block frag
-- * Usage		: start tbfsum.sql <owner> <object> <min tbf>
-- ********************************************************************

def inowner=&&1
def intbl=&&2
def mtbf=&&3

col val9 new_val block_size noprint
select value val9 from v$parameter where name = 'db_block_size';

def osm_prog	= 'tbfsum.sql'
def osm_title	= 'Quick Table Block Fragmentation Report'
start osmtitle

col ownr	format a15 heading 'Owner'
col tbl		format a30 heading 'Table'
col tbf		format 9990.999	   heading 'Table Block|Frag (TBF)' 
col space_used	format 9999,999 heading 'Space Used|(MB)'
col sou		format 9999,999 heading 'Space Once|Used (MB)'


select	owner ownr,
 	table_name tbl,
	(num_rows*avg_row_len)/(0.0000000001+blocks*&block_size) tbf,
	(num_rows*avg_row_len/1024/1024) space_used,
	(blocks*&block_size/1024/1024) sou
from    dba_tables
where   owner like upper('&inowner%')
  and	table_name like upper('&intbl%')
  and   ((num_rows*avg_row_len)/(0.0000000001+blocks*&block_size)) > &mtbf
order by 3 desc
/

start osmclear

