-- ********************************************************************
-- * Copyright Notice   : (c)1998 OraPub, Inc.
-- * Filename		: tcsizing.sql 
-- * Author		: Craig A. Shallahamer
-- * Original		: 11-OCT-01
-- * Last Update	: 11-OCT-01
-- * Description	: Create touch count sizing report
-- * Usage		: start tcsizing.sql
-- ********************************************************************

drop table bogus_tcsizing;
create table bogus_tcsizing (tc number, tot_blocks number)
tablespace tools;

set echo on feedback on

declare
  i number;
  j number;
  k number;
  l number;
begin
  for i in 0..200 loop
          insert into bogus_tcsizing (tc,tot_blocks) 
		select i,count(*) 
		from   sys.x$bh
		where  tch = i;
  end loop;
  commit;
end;
/
set pagesize 5000
select * from bogus_tcsizing;
select sum(tot_blocks) from bogus_tcsizing where tc > 0;
select sum(tot_blocks) from bogus_tcsizing where tc > 1;
select sum(tot_blocks) from bogus_tcsizing where tc > 2;
select sum(tot_blocks) from bogus_tcsizing where tc > 3;
select sum(tot_blocks) from bogus_tcsizing where tc > 4;
select sum(tot_blocks) from bogus_tcsizing where tc > 5;
select sum(tot_blocks) from bogus_tcsizing where tc > 6;
select sum(tot_blocks) from bogus_tcsizing where tc > 7;
select sum(tot_blocks) from bogus_tcsizing where tc > 8;
select sum(tot_blocks) from bogus_tcsizing where tc > 9;
select sum(tot_blocks) from bogus_tcsizing where tc > 10;

select sum(tot_blocks) from bogus_tcsizing;
drop table bogus_tcsizing;


