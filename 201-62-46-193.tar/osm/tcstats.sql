-- file		: tcstats.sql
-- description	: touch count statsistics to help size BCs
-- author	: (orig) John Beresniewicz
--		  (mods) Craig Shallahamer (craig@orapub.com)
-- orig		: 01-oct-01


prompt RECYCLE Pool Candidates

col object	format a40		heading "Object"
col owner	format a20		heading "Owner"
col name	format a25		heading "Name"
col buffers	format 999,999,990	heading "Buffers"
col pct_cache	format 990.00		heading "PCT of Cache"

select	obj		object,
	count(1)	buffers,
	100*(count(1)/totsize) pct_cache
from	sys.x$bh,
	(select value totsize
	 from   v$parameter
	 where  name = 'db_block_buffers'
	)
where	( tch = 1
   or	 (tch = 0 AND lru_flag < 8)
	)
group by obj,totsize
having	100*(count(1)/totsize) > 5
/

col owner format a25
col object_name  format a35 
select owner,object_name
from   dba_objects
where  object_id = &objid
/


select	object_id,owner,object_name
from	dba_objects
where	object_id in (
		select  obj 
		from    sys.x$bh x,
        		(select value totsize
         		 from   v$parameter
         		 where  name = 'db_block_buffers'
        		)
		where   
        		( tch = 1
   		   or    (tch = 0 AND lru_flag < 8)
        		)
		group by obj,totsize
		having  100*(count(1)/totsize) > 5
	)
/

prompt KEEP Pool Candidates

select	obj		object,
	count(1)	buffers,
	avg(tch)	avg_touches
from	sys.x$bh
where	lru_flag = 8
group by obj
having	avg(tch) > 5
   and  count(1) > 20
/

set pagesize 999
select	tch	"Touch Count",
	dbarfil "File #",
	dbablk	"Blk #"
from	sys.x$bh
order by tch
/


select	tch	"Touch Count",
	dbarfil "File #",
	dbablk  "Blk #"
from	sys.x$bh
order by tch
/

set echo on
select count(*) from sys.x$bh where tch <= 0 and tch > -1;
select count(*) from sys.x$bh where tch <= 1 and tch > 0;
select count(*) from sys.x$bh where tch <= 2 and tch > 1;
select count(*) from sys.x$bh where tch <= 3 and tch > 2;
select count(*) from sys.x$bh where tch <= 4 and tch > 3;
select count(*) from sys.x$bh where tch <= 5 and tch > 4;
select count(*) from sys.x$bh where tch <= 6 and tch > 5;
select count(*) from sys.x$bh where tch <= 7 and tch > 6;
select count(*) from sys.x$bh where tch <= 8 and tch > 7;
select count(*) from sys.x$bh where tch <= 9 and tch > 8;
select count(*) from sys.x$bh where tch <= 10 and tch > 9;
select count(*) from sys.x$bh where tch <= 11 and tch > 10;
select count(*) from sys.x$bh where tch <= 12 and tch > 11;
select count(*) from sys.x$bh where tch <= 13 and tch > 12;
select count(*) from sys.x$bh where tch <= 14 and tch > 13;
select count(*) from sys.x$bh where tch <= 15 and tch > 14;
select count(*) from sys.x$bh where tch <= 16 and tch > 15;
select count(*) from sys.x$bh where tch <= 17 and tch > 16;



