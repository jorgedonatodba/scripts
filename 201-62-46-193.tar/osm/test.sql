------------------------------------------------------------
-- file		ashepcte.sql
-- desc		ASH system level wait time pct, last x min (<min>)
-- author	Craig A. Shallahamer, craig@orapub.com
-- orig		02-April-07
-- lst upt	02-April-07 
-- copyright	(c)2007 OraPub, Inc.

-- It is possible to get percentages greater/lesser than 100% because there
-- is a time lag between the total calculations and the report query
------------------------------------------------------------

set echo off
set feedback off
set heading off
set verify off
set termout off

def sleep_time_min=&1

col val1 new_val tot_time_waited

select	sum(ash.wait_time+ash.time_waited) val1
from	v$active_session_history ash
where	ash.sample_time between (sysdate-&sleep_time_min/(60*24)) and sysdate
  and	ash.event not in
		(	select a.event
            from   o$event_type a
            where  a.type in ('bogus','idle')
        )
/

set echo off
set feedback off
set heading on
set verify off
set termout on

def osm_prog    = 'ashpcte.sql'
def osm_title   = 'System Level ASH Wait Percent (last &sleep_time_min min)'

start osmtitle

col event       format a38      heading "Wait Event" trunc
col time_pct    format 990.00   heading "% Time|Waited"
	
select	ash.event,
		100*(sum(ash.wait_time+ash.time_waited)/&tot_time_waited) time_pct
from	v$active_session_history ash
where	ash.sample_time between (sysdate-&sleep_time_min/(60*24)) and sysdate
  and	ash.event not in
		(	select a.event
            from   o$event_type a
            where  a.type in ('bogus','idle')
        )
group by ash.event
having 100*(sum(ash.wait_time+ash.time_waited)/&tot_time_waited) > 0.01
order by time_pct desc
/



start osmclear

--This may be helpful
--select	to_char(sysdate,'DD-Mon-YY HH24:MI:SS') now,
--		to_char(sysdate-24/24,'DD-Mon-YY HH24:MI:SS') one_day_prior,
--		to_char(sysdate-1/24,'DD-Mon-YY HH24:MI:SS') one_hour_prior,
--		to_char(sysdate-1/(60*24),'DD-Mon-YY HH24:MI:SS') one_min_prior,
--		to_char(sysdate-30/(60*24),'DD-Mon-YY HH24:MI:SS') thirty_min_prior
--from dual;


