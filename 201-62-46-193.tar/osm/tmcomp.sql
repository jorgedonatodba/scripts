-- ********************************************************************
-- * Copyright Notice	: (c)2015 OraPub, Inc.
-- * Filename			: tmcomp.sql - active session activity compare script
-- * Author				: Craig A. Shallahamer
-- * Original			: 3-Aug-2015
-- * Last Update		: 12-Aug-2015
-- * Description		: Compare Oracle time based and sample (ASH) base stats
-- * Usage				: @tmcomp.sql
-- ********************************************************************

-- Oracle time model assumptions. See my blog postings for details
-- db time = cpu time                    + non idle wait time
-- db time = db cpu + os cpu queue time  + non idle wait time
-- However, any time model error will be included in the "os cpu queue time"
-- Unfortunately, Oracle calls "os cpu queue time" "cpu wait time"...see my blog posts

set feedback off head on echo off tab off
set linesize 250

-- At the bottom of script, ShowTitle is set to NO.
-- So, when the script is re-run, the ShowTitle will stay NO, so no title print
def ShowTitle="YES"

-- This must be run to initialize/re-set the variables.
-- However, when this script is quickly re-run by enter a "/"
-- the variables will NOT be reset. This is what we want!
start osmsetvar.sql

accept ENTERinst  prompt "ENTER inst_id           (default: 1) : " default 1
accept ENTERsid   prompt "ENTER sid               (default: 0) : " default 0
prompt

col inst_id		format 99		heading "Inst#"
col sid			format 999999	heading "SID"
col serial		format 999999	heading "Ser"
col statex		format a7		heading "State"
col eventx		format a40		heading "Wait Event Name" trunc
col params		format a20		heading	"Wait Event Parameters"
col p1text		format a10		heading "P1 Text" trunc
col objnum		format 9999999999		heading "Row Wait Obj #"
col bs			format 999999	heading "Blking Sess"
col ci			format a15		heading "Client ID Info" trunc
col modulex		format a20		heading "Module" trunc
col sql_idx		format a20		heading "SQL ID" trunc
col tot_cpu_s	format 99990.0 heading "Total|CPU sec"
col tot_wait_s	format 99990.0 heading "Total|Wait sec"

set serveroutput on

set verify off
set linesize 220
set heading on

declare
	cpu_queue_s_v		number;
	cpu_tot_s_v			number;
	output1_v			varchar2(500);
	output2_v			varchar2(500);
	output3_v			varchar2(500);
	tba_cpu_pct_v		number;
	tba_wait_pct_v		number;
	ash_cpu_pct_v		number;
	ash_wait_pct_v		number;
	delta_s_v			number;
	small_v				number := 0.0000000000000010 ;
begin
    if ( '&ShowTitle' = 'YES' ) then
        	
		output1_v := 'Sample      Time Based        ASH Based       |  Time Based Details (s)                ASH Samples      ';    
		output2_v := 'Time (s)    CPU %    Wait %   CPU %   Wait %  |  db time  db cpu   cpu os Qt  ni wait  cpu #    wait #  ';
		output3_v := '----------  -------  -------  ------  ------  |  -------  -------  ---------  -------  -------  ------- ';

		dbms_output.put_line( output1_v );
		dbms_output.put_line( output2_v );    
		dbms_output.put_line( output3_v );
    end if;

    -- Calculate the delta values
    --
	select ((value/1000000)-:tcomp_db_cpu_s_v)
	into   :tcomp_db_cpu_s_v
	from	gv$sess_time_model
	where	inst_id = &ENTERinst
	  and	sid = &ENTERsid
	  and	stat_name = 'DB CPU';

	select ((value/1000000)-:tcomp_db_time_s_v)
	into   :tcomp_db_time_s_v
	from	gv$sess_time_model
	where	inst_id = &ENTERinst
	  and	sid = &ENTERsid
	  and	stat_name = 'DB time';

	select (sum(time_waited/100)-:tcomp_tot_wait_s_v)
	into   :tcomp_tot_wait_s_v
	from	gv$session_event
	where	inst_id = &ENTERinst
	  and	sid = &ENTERsid
	  and	wait_class != 'Idle';  
	  
	cpu_tot_s_v		:= :tcomp_db_time_s_v - :tcomp_tot_wait_s_v ;
	cpu_queue_s_v 	:= cpu_tot_s_v - :tcomp_db_cpu_s_v ;
	
	select	count(*)
	into	:tcomp_ash_cpu_count_v
	from	gv$active_session_history
	where	inst_id = &ENTERinst
	  and	session_id = &ENTERsid
  	  and	session_state = 'ON CPU'
  	  and 	sample_id > :tcomp_ash_last_sample_id_v;	  

	select	count(*)
	into	:tcomp_ash_wait_count_v
	from	gv$active_session_history
	where	inst_id = &ENTERinst
	  and	session_id = &ENTERsid
	  and	session_state = 'WAITING'
  	  and 	sample_id > :tcomp_ash_last_sample_id_v;	  
	  
	tba_cpu_pct_v		:= 100 * ( cpu_tot_s_v / ( small_v + :tcomp_db_time_s_v )) ;
	tba_wait_pct_v		:= 100 * ( :tcomp_tot_wait_s_v / :tcomp_db_time_s_v ) ;
	
	ash_cpu_pct_v		:= 100 * ( :tcomp_ash_cpu_count_v / ( small_v + :tcomp_ash_cpu_count_v + :tcomp_ash_wait_count_v ));
	ash_wait_pct_v		:= 100 * ( :tcomp_ash_wait_count_v / ( small_v + :tcomp_ash_cpu_count_v + :tcomp_ash_wait_count_v ));
	
	-- I think we can agree that writing timestamp math is like writing COBAL code
	select	
			round((
			extract( day from diff )*24*60*60*1000 +
			extract( hour from diff )*60*60*1000 +
			extract( minute from diff )*60*1000 +
			extract( second from diff )*1000)/1000
			,2)
	into	delta_s_v
	from 	(	select	systimestamp - to_timestamp( :stamp_time_v, 'YYYY-Mon-DD HH24:MI:SSxFF' ) diff
				from	dual
			)	
	;	

	/*
	dbms_output.put_line('tcomp_db_cpu_s_v='||:tcomp_db_cpu_s_v);
	dbms_output.put_line('tcomp_db_time_s_v='||:tcomp_db_time_s_v);
	dbms_output.put_line('tcomp_tot_wait_s_v='||:tcomp_tot_wait_s_v);
	dbms_output.put_line('cpu_tot_s_v='||cpu_tot_s_v);
	dbms_output.put_line('cpu_queue_s_v='||cpu_queue_s_v);
	dbms_output.put_line('tcomp_ash_cpu_count_v='||:tcomp_ash_cpu_count_v);
	dbms_output.put_line('tcomp_ash_wait_count_v='||:tcomp_ash_wait_count_v);
	dbms_output.put_line('tcomp_ash_last_sample_id_v='||:tcomp_ash_last_sample_id_v);
	dbms_output.put_line('delta_s_v='||delta_s_v);
	*/

	output3_v := '_' ||
		lpad(to_char(round(delta_s_v,1),'99990D0'),9,' ')||'  '||
		lpad(to_char(round(tba_cpu_pct_v,1),'9990D0'),7,' ')||'  '||
		lpad(to_char(round(tba_wait_pct_v,1),'9990D0'),7,' ')||'  '||
		lpad(to_char(round(ash_cpu_pct_v,1),'990D0'),6,' ')||'  '||
		lpad(to_char(round(ash_wait_pct_v,1),'990D0'),6,' ');
		
	output3_v := output3_v || '  |  ' || 
		lpad(to_char(round(:tcomp_db_time_s_v,1),'9990D0'),7,' ')||'  '||
		lpad(to_char(round(:tcomp_db_cpu_s_v,1),'9990D0'),7,' ')||'  '||
		lpad(to_char(round(cpu_queue_s_v,1),'9990D0'),9,' ')||'  '||
		lpad(to_char(round(:tcomp_tot_wait_s_v,1),'9990D0'),7,' ')||'  '||
		
		lpad(to_char(round(:tcomp_ash_cpu_count_v,1),'999990'),7,' ')||'  '||
		lpad(to_char(round(:tcomp_ash_wait_count_v,1),'999990'),7,' ');

	dbms_output.put_line(output3_v);
	
	-- Set the initial values for the next run
	--
	select	(value/1000000)
	into   	:tcomp_db_cpu_s_v
	from	gv$sess_time_model
	where	inst_id = &ENTERinst
	  and	sid = &ENTERsid
	  and	stat_name = 'DB CPU';

	select 	(value/1000000) 
	into   	:tcomp_db_time_s_v
	from	gv$sess_time_model
	where	inst_id = &ENTERinst
	  and	sid = &ENTERsid
	  and	stat_name = 'DB time';
  
	select sum(time_waited/100)
	into   :tcomp_tot_wait_s_v
	from	gv$session_event
	where	inst_id = &ENTERinst
	  and	sid = &ENTERsid
	  and	wait_class != 'Idle';  	  

  	select	max(sample_id)
  	into	:tcomp_ash_last_sample_id_v
	from	gv$active_session_history
	where	inst_id = &ENTERinst
	  and	session_id = &ENTERsid;
  	    
  	select	to_char(systimestamp,'YYYY-Mon-DD HH24:MI:SSxFF')
	into	:stamp_time_v
	from	dual;
	
end;
/

def ShowTitle="NO"

prompt
prompt Enter / to run again!

